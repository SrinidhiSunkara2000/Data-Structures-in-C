#define MAX (10)
struct queue
{
	 int front,rear;
	int arr[10];
}Q;
void create()
{
	Q.front=-1;
	Q.rear=-1;
	printf("\n Empty queue created successfully");
}
void enqueue(int ele)
{
	
	if(isfull())
	{
		printf("\n Overflow error");
		return;
	}
	else if(Q.rear==MAX-1)
	{
		Q.rear=0;
		Q.arr[Q.rear]=ele;
	}
	else 
	{
		Q.rear=Q.rear+1;
		Q.arr[Q.rear]=ele;
	}
	//printf("%d",Q.arr[Q.rear]);
	if(Q.front==-1)
	{
		//printf("Queue %d",Q.front);
		Q.front=0;
	}
	printf("\n Element inserted");
}

int isfull()
{
	if(Q.front==Q.rear+1 || (Q.front==0&&Q.rear==MAX-1))
		return 1;
	else 
		return 0;
}
int isempty()
{
	if(Q.front==-1)
	{
		return 1;
	}
	else
		return 0;
}
void dequeue()
{
	if(Q.front==-1)
	{
		printf("\n Cannot dequeue from empty queue");
		return;
	}
	else if(Q.front==MAX-1)
	{
		Q.front=0;
	}
	else
	{
		Q.front=Q.front+1;
	}
	printf("\n Element deleted successfully");
}
void display()
{
	int r,i;
	if(Q.front<=Q.rear)
	{
	for(i=Q.front;i<=Q.rear;i++)
	{
		if(i==Q.front)
		{
			printf("\nFront->");
		}
		if(i==Q.rear)
		{
			printf("\nRear->");
		}
		printf("\t%d\n",Q.arr[i]);
		}
	}
	else
	{
		for(i=Q.front;i<MAX;i++)
		{
			printf("\n %d",Q.arr[i]);
		}
		for(i=0;i<Q.rear;i++)
		{
			printf("\n %d",Q.arr[i]);
		}
	}
}
void front()
{
	printf("\nFront:%d->",Q.front);
	printf("\t%d",Q.arr[Q.front]);
}

void rear()
{
	printf("\nRear:%d->",Q.rear);
	printf("\t%d",Q.arr[Q.rear]);
}
