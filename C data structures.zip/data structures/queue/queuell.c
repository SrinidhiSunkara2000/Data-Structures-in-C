#include"headerl.h"
struct node{
	int data;
	struct node *next;
};
	struct node *front=NULL;
struct node *rear=NULL;
void create()
{
   front=rear=NULL;
    printf("the queue is successfully created\n");
}
void dispose()
{
	front=rear=NULL;
	printf("the queue is successfully disposed\n");
}
void enqueue(int x)
{
	struct node *temp = malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	if((front==NULL)&&(rear==NULL)){
		front=rear=temp;
	}
	else{
	rear->next=temp;
	rear=temp;}
	
 } 
void dequeue()
 {
 	struct node *temp=malloc(sizeof(struct node));
 	temp=front;
 	if(front == NULL)
 	{
 		printf("the queue is already empty cannot delete elements\n");
 		return;
	 }
	 if(front==rear)
	 {
	 	front=rear=NULL;
	 }
	 else{
	 	
 	front=front->next;}
 	free(temp);
 }
void display()
  {
  	if(front==NULL&&rear==NULL)
  	printf("queue is empty\n");
  	else{
  	struct node *temp=front;
  	if(front==rear)
  	printf("front-->%d-->rear\n",front->data);
  	else{
    printf("front-->%d\n",temp->data);
    
  	while(temp != NULL)
  	{
  		if(temp==rear)
  		printf("\t%d-->rear\n",temp->data);
  		
  		else if (temp!=rear && temp!=front)
		printf("\t%d\n",temp->data);
  		temp=temp->next;
	  }
    }
  }
}
void tofront()
 {
 	if(front==NULL)
 	{
 		printf("the queue is empty\n");
	 }
	 else{
	 	printf("front-->%d\n",front->data);
	 }
  } 
void torear()
  {
  		if(rear==NULL)
 	{
 		printf("the queue is empty\n");
	 }
	 else{
	 	printf("%d-->rear\n",rear->data);
	 }
  	
  }
void isempty()
 {
 	if((front==NULL)&&(rear==NULL))
 	{
 		printf("empty queue\n");
 	}
 	else
 	printf("queue is not empty\n");
 }
 /*
 void main(){
 	int ch;
 	printf("MENU\n1.ENQUEUE\n2.DEQUEUE\n3.DISPLAY\n4.FRONT\n5.ISEMPTY");
 	printf("\nenter -1 to exit\nenter choice:");
 	scanf("%d",&ch);
	 do
 	{
 		
 		switch(ch)
 		{
 			case 1:{
 				int x;
 				printf("enter the data to be inserted:");
 				scanf("%d",&x);
 					enqueue(x);
				break;
			 }
			 case 2:{
			 	dequeue();
				break;
			 }
			 case 3:{
			 	display();
				break;
			 }
			 case 4:{
			 	tofront();
				break;
			 }
			 case 5:{
			 	isempty();
				break;
			 }
 			
		 }
		 printf("enter the choice:");
		 scanf("%d",&ch);
	 }while(ch!=-1);
 }*/
 
