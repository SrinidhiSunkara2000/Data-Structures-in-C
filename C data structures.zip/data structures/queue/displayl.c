#include"queuell.c"
void main(){
 	int ch;
 	printf("MENU\n1.ENQUEUE\n2.DEQUEUE\n3.DISPLAY\n4.FRONT\n5.ISEMPTY\n6.DISPOSE\n7.REAR\n8.CREATE");
 	printf("\nenter -1 to exit\nenter choice:");
 	scanf("%d",&ch);
	 do
 	{
 		
 		switch(ch)
 		{
 			case 1:{
 				int x;
 				printf("enter the data to be inserted:");
 				scanf("%d",&x);
 					enqueue(x);
				break;
			 }
			 case 2:{
			 	dequeue();
				break;
			 }
			 case 3:{
			 	display();
				break;
			 }
			 case 4:{
			 	tofront();
				break;
			 }
			 case 5:{
			 	isempty();
				break;
			 }
			 case 6:{
			 	dispose();
				break;
			 }
			 case 7:{
			 	torear();
				break;
			 }
			 case 8:{
			 	create();
				break;
			 }
 			
		 }
		 printf("enter the choice:");
		 scanf("%d",&ch);
	 }while(ch!=-1);
 }
 
