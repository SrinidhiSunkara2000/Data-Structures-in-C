#include<stdio.h>
#include<stdlib.h>
struct queue
{
	int data;
	struct queue *next;
}*front=NULL,*rear=NULL;
int count=0;
void display()
{
	int i;
	struct queue *temp=front;
	if(temp==NULL)
	{
		printf("\n Queue is empty");
		return;
	}
	printf("\n Queue :\n");
	while(temp->next!=front)
	{
		printf("%d->",temp->data);
		temp=temp->next;
	}
	printf("%d",temp->data);
}
void josephus(int m)
{
	int i,c;
	struct queue *prev,*cur;
	prev=front;
	cur=front;
	while(cur->next!=cur)
	{
		c=1;
		while(c!=m)
		{
			prev=cur;
			cur=cur->next;
			c++;
		}
		prev->next=cur->next;
		cur=cur->next;
	}
	printf("\nSurvivor:%d",cur->data);
}
void create()
{
	int choice;
	struct queue *newnode;
	do
	{
		newnode=malloc(sizeof(struct queue));
		printf("Enter the data");
		scanf("%d",&newnode->data);
		newnode->next=NULL;
		if(front==NULL && rear==NULL)
		{
			front=newnode;
			rear=newnode;
		}
		else
		{
			rear->next=newnode;
			rear=newnode;
			rear->next=front;
		}
		count++;
		printf("\n To continue, Press 1:");
		scanf("%d",&choice);
	}while(choice==1);
	display();
}
void main()
{
	int m;
	printf("\n Enter the value of m");
	scanf("%d",&m);
	create();
	josephus(m);
}
