typedef struct queue
{
	char name[30],descript,report[50];
	struct queue *next;
}queue;
typedef struct queue* q;
queue *front1=NULL,*rear1=NULL,*front2=NULL,*rear2=NULL;

void create(queue *f,queue*r)
{
	f=NULL;
	r=NULL;
}
void s_dequeue()
{
    struct node *temp;
    if(front1 == NULL)
         printf("Queue is Empty. Unable to perform dequeue\n");
    else
    {
        temp = front1;
        front1 = front1->next;
        if(front1 == NULL)
            rear1 = NULL;
        free(temp);
    }
}
void display(queue *front)
{
	int count=1;
	struct queue *temp=front;
	if(front==NULL)
	{
		printf("\n Empty queue");
		return;
	}
	printf("\n Queries so far:\n");
	while(temp)
	{
		printf("\n Report number :%d",count);
		printf("\n Employe Name:");
		puts(temp->name);
		printf("\n Type of issue:");
		putchar(temp->descript);
		printf("\n\n Report:");
		puts(temp->report);
		temp=temp->next;
		count++;
	}

}
void type1()
{
	queue *newnode=malloc(sizeof(queue)),*cur;
	printf("\n****Enter the details****");
	printf("\n Enter the employee name:");
	fflush(stdin);
	gets(newnode->name);
	printf("\n Report the issue:");
	fflush(stdin);
	gets(newnode->report);
	fflush(stdin);
	newnode->descript='s';
	//display(newnode);
	if(front1==NULL && rear1==NULL)
	{
		//printf("\nNULL queue");
		newnode->next=NULL;
		front1=newnode;
		rear1=newnode;
	}
	else
	{
		//printf("\n Else part");
		newnode->next=NULL;
		rear1->next=newnode;
		rear1=newnode;
	}
	printf("\n Report successfully added");	
}
void type2()
{
	queue *newnode=malloc(sizeof(queue)),*cur;
	printf("\n****Enter the details****");
	printf("\n Enter the employee name:");
	fflush(stdin);
	gets(newnode->name);
	printf("\n Report the issue:");
	fflush(stdin);
	gets(newnode->report);
	fflush(stdin);
	newnode->descript='h';
	if(front2==NULL && rear2==NULL)
	{
		newnode->next=NULL;
		front2=newnode;
		rear2=newnode;
	}
	else
	{
		newnode->next=NULL;
		rear2->next=newnode;
		rear2=newnode;
	}
	printf("\n Report successfully added");	
}
void hdequeue()
{
    struct node *temp;
    if(front2 == NULL)
         printf("Queue is Empty. Unable to perform dequeue\n");
    else
    {
        temp = front2;
        front2 = front2->next;
        if(front2 == NULL)
            rear2 = NULL;
        free(temp);
    }
}

void input()
{
	int n,c,i=1,choice;
	char s;
	printf("\n Enter the number of reports");
	scanf("%d",&n);
	do{
	printf("\n Enter the type of issue:\n1.hostel issue(s)\t2.bus issue(h)");
	scanf("%d",&c);
	if(c==1)
	{
		type1(front1,rear1);
	}
	else if(c==2)
		type2(front2,rear2);
	i++;
	}while(i<=n);
	printf("\n Do you want to dequeue?(1/0)");
	scanf("%d",&choice);
	if(choice==1)
	{
		printf("\n Which issue is to be resolved");
		fflush(stdin);
		s=getchar();
		if(s=='s')
			s_dequeue();
		else
			hdequeue();
	}
	printf("\n hostel issues:\n");
	display(front1);
	printf("\n bus issues:\n");
	display(front2);
}

