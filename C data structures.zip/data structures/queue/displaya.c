#include"queue.c"
void main()
{
	int ch;
	printf("1.create\n2.enqueue\n3.dequeue\n4.display\n5.isempty\n6.isfull\n7.dispose\n8.frontandrear\nenter -1 to exit\nenter choice:");
	scanf("%d",&ch);
	do{
		
		switch(ch)
		{
			case 1:{
				create();
				break;
			}
			case 2:{
				int ele;
				printf("enter the element to be inserted:");
				scanf("%d",&ele);
				enqueue(ele);
				break;
			}
			case 3:{
				dequeue();
				break;
			}
			case 4:{
				display();
				break;
			}
			case 5:{
				isempty();
				break;
			}
			case 6:{
				isfull();
				break;
			}
			case 7:{
				dispose();
				break;
			}
			case 8:{
				front_and_rear();
				break;
			}
		}
			printf("\nenter the choice:");
			scanf("%d",&ch);
	}while(ch!=-1);
	
	
}
