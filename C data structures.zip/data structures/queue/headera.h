#include<stdio.h>
#define max 6
