#include<stdio.h>
#include<stdlib.h>
#include "qhead.h"
void main()
{
	printf("\n**********Technical help desk**********");
	printf("\n Report any hostel or bus complaints\n");
	input();
}
