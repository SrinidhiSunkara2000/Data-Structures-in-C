#include"bst.h"
struct node{
	int data;
	struct node *left;
	struct node *right;
};
struct node *root;

struct node* getnode()
{
	struct node *new_node=malloc(sizeof(struct node));
	new_node->left=NULL;
	new_node->right=NULL;
	return new_node;
}
void traverse(struct node*root,int level)
		{
			if(root==NULL)
			return;
			if(level==1)
			printf("\t\t%d",root->data);
			else if(level>1)
			{
				traverse(root->left,level-1);
				traverse(root->right,level-1);
			}
			
		}
int height(struct node *root)
{
	int max;
	if(root==NULL)
	return -1;
	max=(height(root->left)>height(root->right))?(height(root->left)):(height(root->right));
		return max+1;
}
void display(struct node *root)
{
	struct node *temp;
	temp=root;
	

		int i;
		int height_root=height(root);
		for(i=1;i<=height_root+1;i++)
		{
			printf("\n");
	//		printf("level:%5d\n",i);
			traverse(root,i);
		}
	
		/*
		if(temp!=NULL)
		{
			display(temp->left);
			printf("%d",temp->data);
			display(temp->right);
		}*/
		
	
	
}
void insert(struct node *root,struct node *new_node)
{
	if(new_node->data>root->data)
	{
		if(root->right==NULL)
		root->right=new_node;
		else
		insert(root->right,new_node);
	}
	else
	{
		if(root->left==NULL)
		root->left=new_node;
		else
		insert(root->left,new_node);
	}
}
int search(struct node *root,int ele)
{
	if(root==NULL)
	return -1;
	else if(root->data==ele)
	return 1;
	else if(root->data<ele)
	search(root->right,ele);
	else if(root->data>ele)
	search(root->left,ele);
	else
	return -1;
}
void create_tree(struct node *root)
{
	root=getnode();	
}

void inorder(struct node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		printf("%d",temp->data);
		inorder(temp->right);
	}

}
void preorder(struct node *temp)
{
	if(temp!=NULL)
	{
		printf("%d",temp->data);
		preorder(temp->left);
		preorder(temp->right);
	}
}
void postorder(struct node *temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		printf("%d",temp->data);
	}
}
struct node* min(struct node *root)
{
		struct node *temp=root;
		if(root==NULL)
		return root;
		else
		{
	    while(temp->left!=NULL)
	    temp=temp->left;
	    return temp;
	    }
}
 
struct node * max(struct node *root)
{
	struct node *temp=root;
	if(root==NULL)
	return root;
	else if(temp->right==NULL)
	return temp;
	else
	return max(temp->right);
}
int isempty()
{
	if(root==NULL)
	{
	//	printf("empty tree");
		return 1;
	}
	else
	{
	//	printf("tree is not empty");
		return 0;
	}
}
int size(struct node *root)
{
	int count=0;
	struct node* temp=root;
	if(root==NULL)
	return 0;
	else
	return (1+size(root->left)+size(root->right));
}
struct node *delete(struct node *root,int data)
{
	/*if(root==NULL)
	return root;
	else if(data<root->data)
	root->left=delete(root->left,data);
	else if(data>root->data)
	root->right=delete(root->right,data);
	else
	{*/
		/*if(root->left==NULL&&root->right==NULL)
		{
			//free(root);
			//root=NULL;
			//return root;
			if(root->left==)
		}
		else if(root->left==NULL)
		{
			struct node *temp=root;
			root=root->right;
			free(temp);
			return root;
		}
		else if(root->right==NULL)
		{
			struct node *temp=root;
			root=root->left;
			free(temp);
			return root;
		}
		else
		{
			struct node *temp = min(root->right);
			root->data=temp->data;
			root->right=delete(root->right,temp->data);
			return root;
		}*/
	/*	if(root->left&&root->right)
		{
			struct node *temp;
			temp=min(root->right);
			root->data=temp->data;
			root->right=delete(root->right,root->data);
			return root;
		}
		else
		{
			struct node *temp=root;
			if(root->left==NULL)
			root=root->right;
			else if(root->right==NULL)
			root=root->left;
			free(temp);
			return root;
		}*/
		if(root==NULL)
		{
			return root;
		}
		if(data<root->data)
		root->left=delete(root->left,data);
		else if(data>root->data)
		root->right=delete(root->right,data);
		else
		{
			if(root->left==NULL)
			{
				struct node *temp=root->right;
				free(root);
				return temp;
			}
			else if(root->right==NULL)
			{
				struct node *temp=root->left;
				free(root);
				return temp;
			}
			struct node *temp=min(root->right);
			root->data=temp->data;
			root->right=delete(root->right,temp->data);
			
		}
		return root;
		 
	}



