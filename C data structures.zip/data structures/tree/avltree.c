#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#define max(a,b) (a>b?a:b)
typedef struct avlnode *avltree;
struct avlnode
{
	int data;
	avltree left;
	avltree right;
	int height;	
};

int height(struct avlnode *root)
{
	if(root==NULL)
	return -1;
	else
	return root->height;
}
static avltree srl(avltree k2)
{
	avltree k1;
	k1 = k2->left;
	k2->left = k1->right;
	k1->right = k2;
	k2->height=max(height(k2->right),height(k2->left))+1;
k1->height=max(height(k1->left),k2-> height)+1;
	return k1;
}
static avltree srr(avltree k1)
{
	avltree k2;
	k2 = k1->right;
	k1->right = k2->left;
	k2->left = k1;
    k1->height=max(height(k1->left),height(k1->right))+1;
    k2->height=max(height(k2->right),k1->height)+1;
	return k2;
}
static avltree drl(avltree k3)
{
	k3->left=srr(k3->left);
	return srl(k3);
}
static avltree drr(avltree k3)
{
	k3->right=srl(k3->right);
	return srr(k3);
}
avltree insert(int x,avltree t)
{
	if(t==NULL)
	{
		t = malloc(sizeof(struct avlnode)); //only once
		t->data = x;
		t->left=t->right=NULL;
		t->height=0;	
	}
	else if(x<t->data)
	{
		t->left = insert(x,t->left);
		if((height(t->left)-height(t->right))==2)
		{
			if(x<t->left->data)
			t=srl(t);
			else
			t=drl(t);
		}
	}
	else if(x>t->data)
	{
		t->right=insert(x,t->right);
		if((height(t->right)-height(t->left))==2)
		{
			if(x>(t->right->data))
		    t=srr(t);
		    else
		    t=drr(t);
		}
	}
    t->height=max(height(t->left),height(t->right))+1;
	return t;
}
void traverse(avltree root,int level)
{
	if(root==NULL)
	return;
	if(level==1)
	printf("\t%d\t",root->data);
	else if(level>1)
	{
		traverse(root->left,level-1);
		traverse(root->right,level-1);
	}
}
void display(avltree root)
{
	int i;
	for(i=1;i<=height(root)+1;i++)
	{
		printf("\nlevel:%d\t\n",i);
		traverse(root,i);
	}
}
void main()
{
	int ch,num;
	avltree t;
	t=NULL;
	printf("1.insert\n2.display\nenter -1 to exit");

	do{
			printf("enter choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:{
				/*printf("enter the data to be inserted:");
				scanf("%d",&x);
				t = insert(x,t);
				break;*/
				printf("\nenter number to insert:");scanf("%d",&num);
                 t=insert(num,t);
                printf("\nnumber inserted...\n");break;}
			
		case 2:{
			display(t);
			break;
		}
			printf("enter choice:");
	scanf("%d",&ch);
			
	}
    }while(ch!=-1);
	
}
	

