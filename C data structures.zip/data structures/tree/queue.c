#include"headera.h"
//#define max 6
struct queue{
	int a[max];
	int front;
	int rear;
}q;
int n;
void createq()
{

	printf("enter the size of array:");
	scanf("%d",&n);
	q.front=-1;
	q.rear=-1;
}
void dispose()
{
	q.front=-1;
	q.rear=-1;
	printf("the queue is disposed succeessfully\n");
}
void enqueue(int ele){
	if((q.front==-1)&&(q.rear==-1))
	{q.front=0;q.rear=0;}
	else if((q.rear+1)%n==q.front)
	{
	printf("queue is full");
	return;
    }
	else
	q.rear+=1;
	q.a[q.rear]=ele;
}
void dequeue(){
	if((q.front==-1)&&(q.rear==-1))
	printf("queue is empty cannot delete elements");
	else if (q.front==q.rear)
	{
			q.front=-1;
			q.rear=-1;
	}
	else
	q.front=((q.front+1)%n);

}
void display()
{
	int i;
	if(q.front==-1&&q.rear==-1)
	printf("empty queue");
	else{
	printf("front-->%d\n",q.a[q.front]);	

	for(i=q.front+1;i<=q.rear;i++)
	{
		if(i==q.rear)
			printf("\t%d-->rear",q.a[i]);
				else
		printf("\t%d\n",q.a[i]);
    }}
}
void isempty()
{
	if((q.front==-1)&&(q.rear==-1))
	printf("queue is empty");
	else
	printf("queue is not empty");
}
void isfull()
{
	if(q.front==((q.rear+1)%n))
	printf("queue is full");
	else
	printf("queue is not full");
}
void front_and_rear()
{
	printf("front-->%d",q.a[q.front]);
	printf("%d-->rear",q.a[q.rear]);
}
/*
void main()
{
	int ch;
	printf("1.create\n2.enqueue\n3.dequeue\n4.display\n5.isempty\n6.isfull\nenter -1 to exit\nenter choice:");
	scanf("%d",&ch);
	do{
		
		switch(ch)
		{
			case 1:{
				create();
				break;
			}
			case 2:{
				int ele;
				printf("enter the element to be inserted:");
				scanf("%d",&ele);
				enqueue(ele);
				break;
			}
			case 3:{
				dequeue();
				break;
			}
			case 4:{
				display();
				break;
			}
			case 5:{
				isempty();
				break;
			}
			case 6:{
				isfull();
				break;
			}
		}
			printf("\nenter the choice:");
			scanf("%d",&ch);
	}while(ch!=-1);
	
	
}*/
