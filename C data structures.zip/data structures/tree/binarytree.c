#include<stdio.h>
#include"bt.c"
/*#include<stdio.h>
#include<malloc.h>
struct node{
	int data;
	struct node *left;
	struct node *right;
};
struct node *root;

struct node* getnode()
{
	struct node *new_node=malloc(sizeof(struct node));
	new_node->left=NULL;
	new_node->right=NULL;
	return new_node;
}
void create_tree(struct node *root)
{
	root=getnode();	
}
int isempty()
{
	if(root==NULL)
	{
	//	printf("empty tree");
		return 1;
	}
	else
	{
	//	printf("tree is not empty");
		return 0;
	}
}

void insert(struct node *root,struct node *new)
{
	char ch;
	printf("\nwhere to insert left or right of %d:",root->data);
	ch=getche();
	if((ch=='r')||(ch=='R'))
	{
		if(root->right==NULL)
		{
			root->right=new;
		}
		else
		{
			insert(root->right,new);
		}
	}
	else
	{
		if(root->left==NULL)
		{
			root->left=new;
		}
		else
		{
			insert(root->left,new);
		}
	}
}
void inorder(struct node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		printf("%d",temp->data);
		inorder(temp->right);
	}
}
void preorder(struct node *temp)
{
	if(temp!=NULL)
	{
		printf("%d",temp->data);
		preorder(temp->left);
		preorder(temp->right);
	}
}
void postorder(struct node *temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		printf("%d",temp->data);
	}
}
int size(struct node *root)
{
	if(root==NULL)
	return 0;
	else
	return (1+size(root->left)+size(root->right));
}
int count_leaf(struct node *root)
{
	if(root==NULL)
	return 0;
	else if((root->right==NULL)&&(root->left==NULL))
	return 1;
	else 
	return (count_leaf(root->left)+count_leaf(root->right));
}
void traverse(struct node*root,int level)
		{
			if(root==NULL)
			return;
			if(level==1)
			printf("%d\n",root->data);
			else if(level>1)
			{
				traverse(root->left,level-1);
				traverse(root->right,level-1);
			}
			
		}
int height(struct node *root)
{
	int max;
	if(root==NULL)
	return -1;
	max=(height(root->left)>height(root->right))?(height(root->left)):(height(root->right));
		return max+1;
}
void display(struct node *root)
{
	struct node *temp;
	temp=root;
	

		int i;
		int height_root=height(root);
		for(i=1;i<=height_root+1;i++)
		{
			printf("level:%d\n",i);
			traverse(root,i);
		}
		
}*/

void main()
{
	int ch;
	
	do
	{
			printf("\nMENU\n1.create\n2.insert\n3.inorder\n4.preorder\n5.postorder\n6.display\n7.size\n8.count_leaf\n9.height\n10.isempty\nenter -1 to exit\n enter choice: ");
	scanf("%d",&ch);

	switch(ch)
	{
		case 1:{
			create_tree(root);
			break;
		}
		case 2:{
			struct node *new_node;
			int x;
			printf("enter the node to be inserted:");
			new_node=getnode();
			scanf("%d",&x);
			new_node->data=x;
			if(root==NULL)
			root=new_node;
			else{
		     	insert(root,new_node);
		     }
		     fflush(stdin);
			break;
		}
		case 3:{
			inorder(root);
			break;
		}
		case 4:{
			preorder(root);
			break;
		}
		case 5:{
			postorder(root);
			break;
		}
		case 6:{
			display(root);
			break;
		}
		case 7:{
		    int x;
		    x=size(root);
		    printf("the no of nodes in tree are:%d",x);
			break;
		}
		case 8:{
			int x;
		    x=count_leaf(root);
		    printf("the no of leaf nodes in tree are:%d",x);
			break;
		}
		case 9:{
			printf("height of tree is:%d",height(root));
			break;
		}
		case 10:{
			if(isempty())
			printf("tree is empty");
			else
			printf("tree is not empty");
			break;
		}
	}
		
	
	}while(ch!=-1);
}
