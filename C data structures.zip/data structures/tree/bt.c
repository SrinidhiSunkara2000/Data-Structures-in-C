#include"bt.h"
struct node{
	int data;
	struct node *left;
	struct node *right;
};
struct node *root;

struct node* getnode()
{
	struct node *new_node=malloc(sizeof(struct node));
	new_node->left=NULL;
	new_node->right=NULL;
	return new_node;
}
void create_tree(struct node *root)
{
	root=getnode();	
}
int isempty()
{
	if(root==NULL)
	{
	//	printf("empty tree");
		return 1;
	}
	else
	{
	//	printf("tree is not empty");
		return 0;
	}
}

void insert(struct node *root,struct node *new)
{
	char ch;
	printf("\nwhere to insert left or right of %d:",root->data);
	ch=getche();
	if((ch=='r')||(ch=='R'))
	{
		if(root->right==NULL)
		{
			root->right=new;
		}
		else
		{
			insert(root->right,new);
		}
	}
	else
	{
		if(root->left==NULL)
		{
			root->left=new;
		}
		else
		{
			insert(root->left,new);
		}
	}
}
void inorder(struct node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		printf("%d\t",temp->data);
		inorder(temp->right);
	}
}
void preorder(struct node *temp)
{
	if(temp!=NULL)
	{
		printf("%d\t",temp->data);
		preorder(temp->left);
		preorder(temp->right);
	}
}
void postorder(struct node *temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		printf("%d\t",temp->data);
	}
}
int size(struct node *root)
{
	if(root==NULL)
	return 0;
	else
	return (1+size(root->left)+size(root->right));
}
int count_leaf(struct node *root)
{
	if(root==NULL)
	return 0;
	else if((root->right==NULL)&&(root->left==NULL))
	return 1;
	else 
	return (count_leaf(root->left)+count_leaf(root->right));
}
void traverse(struct node*root,int level)
		{
			if(root==NULL)
			return;
			if(level==1)
			printf("%d\t",root->data);
			else if(level>1)
			{
				traverse(root->left,level-1);
				traverse(root->right,level-1);
			}
			
		}
int height(struct node *root)
{
	int max;
	if(root==NULL)
	return -1;
	max=(height(root->left)>height(root->right))?(height(root->left)):(height(root->right));
		return max+1;
}
void display(struct node *root)
{
	struct node *temp;
	temp=root;
	

		int i;
		int height_root=height(root);
		for(i=1;i<=height_root+1;i++)
		{
			printf("\nlevel:%d\n",i);
			traverse(root,i);
		}
	
		/*
		if(temp!=NULL)
		{
			display(temp->left);
			printf("%d",temp->data);
			display(temp->right);
		}*/
		
	
	
}
/*void display(struct node* t)
{
    if (t == NULL)
        return;
    printf("%d",t->data);
 
    if(t->left != NULL)
        printf("(L:%d)",t->left->data);
    if(t->right != NULL)
        printf("(R:%d)",t->right->data);
    printf("\n");
 
    display(t->left);
    display(t->right);
}*/
