#include<stdio.h>
#include<stdlib.h>
#define RIGHT 1
#define LEFT 0
#define TRUE 1
#define FALSE 0

struct node 
{
	int data;
	int height;
	struct node *right;
	struct node *left;
	//struct node *parent;
};

int height(struct node* p)
{
	if(p==NULL)
	return -1;
	else
	return p->height;
}
struct node *srl(struct node *k2)
{
	struct node *k1;
	k1 = k2->left;
	k2->left = k1->right;
	k1->right = k2;
	k2->height = ((height(k2->left)>height(k2->right))?height(k2->left):height(k2->right))+1;
	k1->height=((height(k1->left)>(k2->height))?height(k1->left):k2->height)+1;
    return k1;	
}
struct node *srr(struct node *k1)
{
	struct node *k2;
	k2=k1->left;
	k1->right=k2->left;
	k2->left=k1;
	k1->height=((height(k1->left)>height(k1->right))?height(k1->left):height(k1->right))+1;
  	k2->height=((height(k2->right)>(k1->height))?height(k2->right):k1->height)+1;
    return k2;
}
struct node *drl(struct node *k3)
{
	k3->left=srr(k3->left);
	return srl(k3);
	
}
struct node *drr(struct node *k1)
{
	k1->right=srl(k1->right);
	return srr(k1);
	
}
struct node *insert(int ele,struct node *t)
{
	if(t==NULL)
	{
		t = malloc(sizeof(struct node));
		if(t==NULL)
		{
			printf("error im creating");
			return;
		}
		else
		{
			t->data=ele;
			t->height=0;
			t->left=t->right=NULL;
		}
	}
	else
	{
		if(ele<t->data)
		{
			t->left=insert(ele,t->left);
			if(height(t->left)-height(t->right)==2)
			{
				if(ele<(t->left)->data)
				t=srl(t);
				else
				t=drl(t);
			}
			
		}
		else if(ele>t->data)
		{
			t->right = insert(ele,t->right);
			if(height(t->right)-height(t->left)==2)
			{
				if(ele>(t->right)->data)
				t=srr(t);
				else
				t=drr(t);
			}
			
		}
		t->height = ((height(t->left)>height(t->right))?height(t->left):height(t->right))+1;
	}
	
	return t;
	
}

void traverse(struct node*root,int level)
		{
			if(root==NULL)
			return;
			if(level==1)
			printf("%d\n",root->data);
			else if(level>1)
			{
				traverse(root->left,level-1);
				traverse(root->right,level-1);
			}
			
		}
void display(struct node *root)
{
	struct node *temp;
	temp=root;
	

		int i;
		
		for(i=1;i<=root->height+1;i++)
		{
			printf("level:%d\n",i);
			traverse(root,i);
		}
}
void main()
{
	int ch;
	struct node *root;
	printf("menu\n1.insert\n2.display\nenter -1 to exit\nenter choice:");
	scanf("%d",&ch);
	do
	{
		switch(ch)
	{
		case 1:{
			int ele;
			printf("enter the element to be inserted");
			scanf("%d",&ele);
			insert(ele,root);
			break;
		}
		case 2:{
			display(root);
			break;
		}
	}
	printf("menu\n1.insert\n2.display\nenter -1 to exit\nenter choice:");
	scanf("%d",&ch);
	}while(ch!=-1);
	
}
