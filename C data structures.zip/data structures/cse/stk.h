struct node
{
int data;
struct node *next;
};
typedef struct node *stack;
stack creates()
{
stack s;
s=NULL;
return s;
}

stack push(stack s,int tr)
{
stack ptr;	
ptr = (struct node *)malloc(sizeof(struct node));	
ptr->data=tr;	
if(s==NULL)
{		
ptr -> next = NULL;		
s=ptr;
}
else
{		
ptr -> next =s;		
s= ptr;
}
return s;	
}

int pop(stack s)
{	
stack ptr;int tr;
ptr =s;	
if(s == NULL)	
 printf("\n STACK UNDERFLOW");
else
{
tr=ptr->data;		
s=s->next;		
}	
return tr;
}

int peek(stack s)
{
return s->data;
}
stack move(stack s){return s->next;}
