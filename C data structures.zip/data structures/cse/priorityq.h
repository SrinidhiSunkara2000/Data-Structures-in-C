#include<stdio.h>
#include<stdlib.h>
typedef struct heapstruct *priorityqueue;
typedef int elementtype; 
struct heapstruct
{
int capacity;
int size;
elementtype *elements;
};
priorityqueue init(int maxelements)
{
 int mindata=0;
 int minpqsize=3;
priorityqueue h;
if(maxelements<minpqsize)
  printf("PQueue is too small");
h=malloc(sizeof(struct heapstruct));
if(h==NULL)
 printf("Out of space");
h->elements=malloc((maxelements+1)*sizeof(elementtype));
if(h->elements==NULL)
 printf("Out of Space");
h->capacity=maxelements;
h->size=0;
h->elements[0]=mindata;
return h;
}

//Isempty 
int isempty(priorityqueue h)
{
 return h->size==0;
}

//Isfull
int isfull(priorityqueue h)
{
 return h->size==h->capacity;
}

//Procedure for insertion
void insert(elementtype x, priorityqueue h)
{
int i;
if(isfull(h))
{
  printf("PQueue is full");
  return;
}
for(i=++h->size;h->elements[i/2]>x; i/=2)
h->elements[i] = h->elements[i/2];
h->elements[i]=x;
}


//Function to perform Deletemin in a binary heap
elementtype deletemin(priorityqueue h)
{
int i, child;
elementtype minelement, lastelement;
if(isempty(h))
{
 printf("PQueue is empty");
 return h->elements[0];
}
 minelement=h->elements[1];
 lastelement=h->elements[h->size--];
for(i=1;(i*2)<=h->size;i=child)
{
  child=i*2;
  if(child!=h->size && h->elements[child+1] < h->elements[child])
     child++;
  if(lastelement > h->elements[child])
     h->elements[i]=h->elements[child];
  else
     break;
}
h->elements[i]=lastelement;
return minelement;
}
/*elementtype deletemax(priorityqueue h)
{
int i, child;
elementtype maxelement, lastelement;
if(isempty(h))
{
 printf("PQueue is empty");
 return h->elements[0];
}
 lastelement=h->elements[1];
 maxelement=h->elements[h->size--];
for(i=h->size;(i*2)<=1;i=child)
{
  child=i*2;
  if(child!=h->size && h->elements[child+1] > h->elements[child])
     child--;
  if(maxelement < h->elements[child])
     h->elements[i]=h->elements[child];
  else
     break;
}
h->elements[i]=lastelement;
return maxelement;
}*/

//Routine to display
 void display(priorityqueue h)
 { 
  int i;
  for(i=1;i<=h->size;i++)
  {
   printf("%d ",h->elements[i]);
  }
  printf("\n");
 }

void displaymax(priorityqueue h)
{
	 int i;
  for(i=h->size;i>=1;i--)
  {
   printf("%d ",h->elements[i]);
  }
  printf("\n");
 }
void deletemax(priorityqueue h)
{
	
	h->size-=1;
	}	

