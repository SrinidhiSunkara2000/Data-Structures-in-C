#include "topo.h"
void main()
{
graph g;int v,e;
printf("\nenter number of vertices and edges:\n");
scanf("%d %d",&v,&e);
g=init(v,e);g=create(g);
display(g);
topologicalsort(g);
}
