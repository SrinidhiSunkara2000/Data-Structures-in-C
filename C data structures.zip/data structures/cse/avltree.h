#include <stdio.h>
#include <stdlib.h>
typedef struct avlnode *avltree;
struct avlnode
{
int element;
avltree left;
avltree right;
int height;
};


