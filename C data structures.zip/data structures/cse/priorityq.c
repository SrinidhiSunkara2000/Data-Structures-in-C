#include<stdio.h>
#include"priorityq.h"

void main()
{
 int ch,x;
 priorityqueue q;
 printf("MENU:\n1)Insertion\n2)Min heap Deletion\n3)min heap Display\n4)max heap display\n5)delete in max heap\n6.exit\n");
 printf("enter your choice:");
 scanf("%d",&ch);
 q=init(20);
 while(ch!=6)
 {
  switch(ch)
  {
   case 1:
    printf("enter an element to insert:");
    scanf("%d",&x);
    insert(x,q);
    break;
   case 2:
    deletemin(q);
    printf("Minimum priority element deleted\n");
    break;
   case 3:
    display(q);
    break;
    case 4:{
    	displaymax(q);
		break;
	}
	case 5:
    deletemax(q);
    printf("Maximum priority element deleted\n");
    break;
   }
  printf("enter your choice:");
  scanf("%d",&ch);
 }
 }
     
