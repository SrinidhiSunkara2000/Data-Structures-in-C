#include<stdio.h>
#include<stdlib.h>
#include "arr_queue.h"
struct graphADT
{
int vertices,edges;
int **adj;
};
typedef struct graphADT *graph;

graph init(int vertices,int edges)
{
graph g;
g=(graph)malloc(sizeof(struct graphADT));
g->vertices=vertices;
g->edges=edges;int i,j;
g->adj=(int **)malloc(sizeof(int *)*g->vertices);
for(i=0;i<g->vertices;i++)
{
g->adj[i]=(int *)malloc(sizeof(int)*g->vertices);
for(j=0;j<g->vertices;j++)
 g->adj[i][j]=0;
}
return g;
}

graph create(graph g)
{
int i,v1,v2;char ch;
for(i=0;i<g->edges;i++)
{
printf("\nenter edge %d:\n",(i+1));
scanf("%d%c%d",&v1,&ch,&v2);
g->adj[v1-1][v2-1]=1;
}
return g;
}

void display(graph g)
{
int i,j;
printf("\nedges of graph:\n");
for(i=0;i<g->vertices;i++)
{
for(j=0;j<g->vertices;j++)
 if(g->adj[i][j]==1)
   printf("%d,%d\n",(i+1),(j+1));
}
}

int indeg(graph g,int v)
{
int j,count;count=0;
for(j=0;j<g->vertices;j++)
{
if (g->adj[j][v-1]==1)
 count++;
}
return count;
}

void topologicalsort(graph g)
{
printf("\ntopological sorting:\n");
int counter,j;counter=0;
int v,w;
queue q;q=createqueue(g->vertices);
for(j=0;j<g->vertices;j++)
 if(indeg(g,j+1)==0)
  enqueue(j+1,q);
while(q->size!=0)
{
v=dequeue(q);
printf("%d  ",v);
++counter;
for(w=1;w<=g->vertices;w++)
{
 if(g->adj[v-1][w-1]==1)
 {
  if(indeg(g,w)==1)
   {enqueue(w,q);}
  g->adj[v-1][w-1]=0;
}}}
if(counter!=g->vertices)
 printf("\nGraph is cyclic\n");
}

