//seperate chaining
#include<stdio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node *next;
};
struct node *create_node(int data)
{
  struct node *temp=(struct node *)malloc(sizeof(struct node));
  temp->data=data;
  temp->next=NULL;
  return temp; }
void insert(struct node *hashTable[],int key,int value)
{
  struct node *pos=hashTable[key];
  struct node *temp=create_node(value);   //printf("key,value\n%d,%d\n",key,value);
  if(pos==NULL)
    hashTable[key]=temp;
  else
    {
      while(pos->next!=NULL) pos=pos->next;
      pos->next=temp;
    }
}
int hashFunc(int k)
{
  return k%10;
}
void retreive(struct node *hashTable[],int key)
{
  char ch='y',d;
  int i=0;
  key=hashFunc(key);
  struct node *pos=hashTable[key];
  printf("Search Results: \n");
  scanf("%c",&d);
  while(ch=='y' && pos!=NULL)
    {
      //printf("%d\n",i++);
      printf("%d \n",pos->data);
      printf(" Search for more results?(y/n): ");
      scanf("%c",&ch);
      scanf("%c",&d);
      if(ch=='y')
	pos=pos->next;
    }
  if(pos==NULL)
    printf("No more results available!");
}
void main()
{
  struct node *hashTable[10]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
  int i;
  int key;
  for(i=0;i<30;i++)
    insert(hashTable,rand()%10,rand()%200);
  printf("Enter Key: ");
  scanf("%d",&key);
  retreive(hashTable,key);
  printf("\n");
}

