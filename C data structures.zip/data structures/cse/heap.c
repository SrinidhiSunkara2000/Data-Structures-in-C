#include<stdio.h>
#include<stdlib.h>
#define MAX 10
int n;
int arr[MAX];
void insert(int num)
{
  if(n<MAX)
    {
      arr[n]=num;
      n++;
    }
  else
    {
      printf("Array is full");
    }
}
void make_heap()
{
	int i;
  for(i=1;i<n;i++)
    {
      int val=arr[i];
      int j=i;
      int f=(j-1)/2;

      
      while(j>0&&arr[f]<val)
	{
	  arr[j]=arr[f];
	  j=f;
	  f=(j-1)/2;
	}
      arr[j]=val;
    }
}
void display()
{
	int i;
  for(i=0;i<n;i++)
    {
      printf("%d ",arr[i]);
    }
  printf("\n");
}
void main()
{
  insert(5);
  insert(7);
  insert(4);
  insert(6);
  insert(14);
  insert(8);
  printf("The elements are:\n");
  display();
  printf("\n");
  make_heap();
  printf("Heaped elements are:\n");
  display();
}

  
