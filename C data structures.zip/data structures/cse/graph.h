#include<stdio.h>
#include<stdlib.h>
#include "stk.h"
#include "arr_queue.h"
struct graphADT
{
int vertices,edges;
int **adj;
};
typedef struct graphADT *graph;
//creating an adjacency matrix
graph init(int vertices,int edges)
{
graph g;
g=(graph)malloc(sizeof(struct graphADT));
g->vertices=vertices;
g->edges=edges;int i,j;
g->adj=(int **)malloc(sizeof(int *)*g->vertices);
for(i=0;i<g->vertices;i++)
{
g->adj[i]=(int *)malloc(sizeof(int)*g->vertices);
for(j=0;j<g->vertices;j++)
 g->adj[i][j]=0;
}
return g;
}

graph create(graph g)
{
int i,v1,v2;char ch;
for(i=0;i<g->edges;i++)
{
printf("\nenter edge %d:\n",(i+1));
scanf("%d%c%d",&v1,&ch,&v2);
g->adj[v1-1][v2-1]=1;
}
return g;
}

void display(graph g)
{
int i,j;
printf("\nedges of graph:\n");
for(i=0;i<g->vertices;i++)
{
for(j=0;j<g->vertices;j++)
 if(g->adj[i][j]==1)
   printf("%d,%d\n",(i+1),(j+1));
}
}
int isin(int x,int *arr,int n)
{
int i;
for(i=0;i<n;i++)
 if(arr[i]==x)
  return 1;      
return 0;
}


void DFS(graph g)
{
printf("\nDFS traversal:\n");
stack s; s=creates();int x,t,y;int n;int arr[100];n=0;x=0;
while (n<g->vertices)
{
int l;
for(l=0;l<g->vertices;l++)
{
if(!isin((l+1),arr,n))
 {x=l+1;break;}
}
n++;printf("%d  ",x);arr[n-1]=x;s=push(s,x);
while (s!=NULL)
{
t=peek(s);int i,j;i=0;
for(j=0;j<g->vertices;j++)
{
if((g->adj[t-1][j]==1)&&(!isin(j+1,arr,n)))
 {n++;arr[n-1]=j+1;printf("%d  ",(j+1));s=push(s,j+1);i=1;break;}
}
if(i==0)
 {i=pop(s);s=move(s);}
}
}
}




void BFS(graph g)
{
printf("\nBFS traversal:\n");
queue q;q=createqueue(10); int x, z, y;int n;int arr[100];n=0;x=0;
while (n<g->vertices)
{
int l;
for(l=0;l<g->vertices;l++)
{
if(!isin((l+1),arr,n))
 {x=l+1;break;}
}
n++;printf("%d  ",x);arr[n-1]=x;
enqueue(x,q);
while (q->size!=0)
{
z=dequeue(q);int i,j;
for(j=0;j<g->vertices;j++)
{
if((g->adj[z-1][j]==1)&&(!isin(j+1,arr,n)))
 {n++;arr[n-1]=j+1;printf("%d  ",(j+1));enqueue(j+1,q);}
}
}
}
}


