#include "avltree.c"
void main()
{
int n,num,pos;avltree t;t=NULL;
do{
printf("\nMENU:\n1.insertion\n2.search\n3.find minimum\n4.displaylevel\n5.displayall\n6.maximum\n7.isempty\n8.exit\n9.delete\nenter your choice:\n");
scanf("%d",&n);
switch(n)
{
case 1:
printf("\nenter number to insert:");scanf("%d",&num);
t=insert(num,t);
printf("\nnumber inserted...\n");break;
case 2:
printf("\nenter number to search:");scanf("%d",&num);
t=find(num,t);
if (t!=NULL)
 printf("\nnumber found\n");
else
 printf("\nnumber not found\n");
break;
case 3:
t=findmin(t);
printf("\nminimum element is:%d\n",t->element);break;
case 4:

printf("\nenter the level:\n");
scanf("%d",&pos);
display(t,pos);break;
case 8:
printf("\nprogram terminating....\n");
break;
case 5:{
	printf("displayed in level wise:");
	displayall(t);
	break;
}
case 6:
t=findmax(t);
printf("\nmax element is:%d\n",t->element);break;
case 7:{
	if(isempty(t))
	printf("empty");
	else
	printf("not empty");
	break;
}
case 9:{
			int x;
			struct avlnode *temp;
			printf("enter the element to be deleted:");
			scanf("%d",&x);
			temp=delete(t,x);
			
			break;
		}
}
}while(n!=8);
}
