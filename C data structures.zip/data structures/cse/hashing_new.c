//linear chaining
#include<stdio.h>
#include<stdlib.h>
int hashTable[10];
int hashFunc(int d)
{
return d%10;
}
int retreive(int d)
{
int key=hashFunc(d);
int value=hashTable[key];
return value;
}
void insert(int key,int value)
{
hashTable[key]=value;
}
void main()
{
int i,key;
for(i=0;i<10;i++)
insert(i,rand()%100);
printf("Enter the key: ");
scanf("%d",&key);
printf("The value is: %d\n",retreive(key));
}
