#include"avltree.h"
#define max(a,b) (a>b?a:b)

static avltree singlerotatewithleft(avltree k2)
{
avltree k1;
k1=k2->left;
k2->left=k1->right;
k1->right=k2;
k2->height=max(height(k2->left),height(k2->
right))+1;
k1->height=max(height(k1->left),k2-> height)+1;
return k1;
}

static avltree singlerotatewithright(avltree k2)
{
avltree k1;
k1=k2->right;
k2->right=k1->left;
k1->left=k2;
k2->height=max(height(k2->left),height(k2->
right))+1;
k1->height=max(height(k1->right),k2-> height)+1;
return k1;
}

static avltree doublerotatewithleft(avltree k3)
{ 
k3->left=singlerotatewithright(k3->left);

return singlerotatewithleft(k3);
}

static avltree doublerotatewithright(avltree k3)
{ 
k3->right=singlerotatewithleft(k3->right);

return singlerotatewithright(k3);
}

avltree insert(int x, avltree t)
{
if(t==NULL)
{
t=malloc(sizeof(struct avlnode));
t->element=x;
t->height=0;
t->left=t->right=NULL;
}
else if(x<t->element)
{
t->left=insert(x,t->left);
if((height(t->left) - height(t->right)) ==2)
 if(x<t->left->element)
  t=singlerotatewithleft(t);
 else
  t=doublerotatewithleft(t);
}
else if(x>t->element)
{
t->right=insert(x,t->right);
if((height(t->right)-height(t->left)) == 2)
 if(x>t->right->element)
  t=singlerotatewithright(t);
 else
  t=doublerotatewithright(t);
}
t->height=max(height(t->left),height(t->right))+1;
return t;
}

avltree find(int x, avltree t)
{
if (t==NULL)
 return NULL;
if (x<t->element)
 return find (x, t->left);
else if (x>t->element)
 return find(x,t->right);
else
 return t;
}

avltree findmin(avltree t)
{
if(t==NULL)
 return NULL;
else if(t->left==NULL)
 return t;
else
 return findmin(t->left);
}
avltree findmax(avltree t)
{
if(t==NULL)
 return NULL;
else if(t->right==NULL)
 return t;
else
 return findmax(t->right);
}
int isempty(avltree t)
{
	if(t==NULL)
	{
	//	printf("empty tree");
		return 1;
	}
	else
	{
	//	printf("tree is not empty");
		return 0;
	}
}


/*
void display(avltree t)
{
if(t != NULL)
{		
display(t->left);
		
printf("%d   ", t->element);
		
display(t->right);
}
}*/
void traverse(struct avlnode*root,int level)
		{
			if(root==NULL)
			return;
			if(level==1)
			printf("\t\t%d",root->element);
			else if(level>1)
			{
				traverse(root->left,level-1);
				traverse(root->right,level-1);
			}
			
		}
int height(struct avlnode *root)
{
	int max;
	if(root==NULL)
	return -1;
	max=(height(root->left)>height(root->right))?(height(root->left)):(height(root->right));
		return max+1;
}
void display(struct avlnode *root,int pos)
{
	struct avlnode *temp;
	temp=root;
	

		int i;
		int height_root=height(root);
	/*	for(i=1;i<=height_root+1;i++)
		{
			printf("\n");
			printf("\nlevel:%d\n",i);
			traverse(root,i);
		}
		*/
		printf("\nlevel:%d\n",pos);
		traverse(root,pos);
	
		
	
	
}
void displayall(struct avlnode *root)
{
	struct avlnode *temp;
	temp=root;
	

		int i;
		int height_root=height(root);
	    for(i=1;i<=height_root+1;i++)
		{
			printf("\n");
			printf("\nlevel:%d\n",i);
			traverse(root,i);
		}
}
struct avlnode* min(struct avlnode *root)
{
		struct avlnode *temp=root;
		if(root==NULL)
		return root;
		else
		{
	    while(temp->left!=NULL)
	    temp=temp->left;
	    return temp;
	    }
}
/*
struct avlnode *delete(struct avlnode *root,int data)
{		if(root==NULL)
		{
			return root;
		}
		if(data<root->element)
		root->left=delete(root->left,data);
		else if(data>root->element)
		root->right=delete(root->right,data);
		else
		{
			if(root->left==NULL)
			{
				struct avlnode *temp=root->right;
				free(root);
				return temp;
			}
			else if(root->right==NULL)
			{
				struct avlnode *temp=root->left;
				free(root);
				return temp;
			}
			struct avlnode *temp=min(root->right);
			root->element=temp->element;
			root->right=delete(root->right,temp->element);
			
		}
		return root;
		 
	}

*/

