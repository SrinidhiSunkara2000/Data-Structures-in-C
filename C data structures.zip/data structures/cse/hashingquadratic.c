#include<stdio.h>
#include<stdlib.h>
int hashTable[16];
int hashFunc(int d)
{
  return d*d;
}
void retreive(int key)
{
  int next=hashFunc(key+1);
  key=hashFunc(key);
  int pos=key;
  char ch='y',d;
  scanf("%c",&d);
  printf("Search Results: \n");
  while(ch=='y' && hashTable[pos]!=-1 && pos!=next)
    {
      printf("%d\n",hashTable[pos]);
      printf("Search more results?(y/n): ");
      scanf("%c",&ch);
      scanf("%c",&d);
      if(ch=='y')
	pos++;
    }
  if(hashTable[pos]!=-1 && pos!=hashFunc(key+1))
    printf("No more results available");
}
void insert(int key,int value)
{
  int next=hashFunc(key+1);
  key=hashFunc(key);
  int pos=key;
  while(hashTable[pos]!=-1 && pos!=next)
    {
      pos++;
    }
  if(pos!=hashFunc(key+1))
    hashTable[pos]=value;
}
void main()
{
  for( i=0;i<16;i
  int i,key;++)
    hashTable[i]=-1;
  for(i=0;i<30;i++)
    insert(rand()%4,rand()%100);
  printf("Enter the key: ");
  scanf("%d",&key);
  retreive(key);
  printf("\n");
}
