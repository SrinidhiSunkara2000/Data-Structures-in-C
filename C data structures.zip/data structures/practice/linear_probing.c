#include<stdio.h>
#include<conio.h>
#define max 5
void insert(int a[],int val,int key);
int create(int num);
void display(int a[]);
int create(int num)
{
	int key = num%max;
	return key;
}
void insert(int a[],int val,int key)
{
	if(a[key]==-1)
	{
		a[key]=val;
	
	}
	else
	{
		int count,i,found=0;
		i=0;
		while(i<max)
		{
			if(a[i]!=-1)
			{
				count++;
			}
			i++;
		}
		if(count==max)
		{
			printf("hashtable is full");
			exit(1);
		}
		for(i=key+1;i<max;i++)
		{
			if(a[i]==-1)
			{
				a[i]=val;
				found=1;
				break;
			}
		}
		if(found==1)
		printf("element inserted");
		for(i=0;i<key&&found==0;i++)
		{
			if(a[i]==-1)
			{
				a[i]=val;
				found=1;
				break;
			}
		}
		
	}
}
void display(int a[])
{
	int i;
	for(i=0;i<max;i++)
	printf("\n%d\t%d",i,a[i]);
}
void main()
{
	int ch,a[max];
	printf("MENU\n1.INSERT\n2.DISPLAY\n");
	printf("enter choice");
	scanf("%d",&ch);
	do
	{
		switch(ch)
	{
		case 1:{
			int num,key,i;
			int n;
		
			for(i=0;i<max;i++)
			{
				a[i]=-1;
			}
			do{
				
					printf("enter the val to be inserted");
			scanf("%d",&num);
				key=create(num);
			insert(a,num,key);
			printf("enter 1 to continue:");
			scanf("%d",&n);
			}while(n==1);
		
			
			break;
		}
		case 2:{
			display(a);
			break;
		}
	}
	printf("enter choice");
	scanf("%d",&ch);
	}while(ch!=-1);
}
