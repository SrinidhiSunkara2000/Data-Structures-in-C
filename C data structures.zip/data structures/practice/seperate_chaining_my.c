#include<stdio.h>
#define max 10
#include<malloc.h>
struct node{
	int data;
	struct node *next;
}*head[max]={NULL},*temp,*p,*q;
void insert(int e,int i)
{
	temp=malloc(sizeof(struct node));
	temp->data=e;
	temp->next=NULL;
	if(head[i]==NULL)
	head[i]=temp;
	else
	{
		for(p=head[i];p->next!=NULL;p=p->next);
		p->next=temp;
	}
}
void delete(int e,int i)
{
	q=NULL;
	for(p=head[i];p!=NULL&&p->data!=e;p=p->next)
	q=p;
	if(p==NULL)
	{
		printf("element not found");
		return;
	}
	if(q==NULL)//first element is the one to be deleted 
	{
		head[i]=p->next;
		free(p);
		return;
	}
	q->next=p->next;
	free(p);
}
void display(int i)
{
	printf("\nposition:%d\t\t",i);
	for(p=head[i];p!=NULL;p=p->next)
	printf("%d->",p->data);
}
void main()
{
	int i,ch;
	printf("1.insertion  2.deletion 3.display -1 to exit");
	do
	{
		printf("\nenter the choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:{
				int i,e;
				printf("enter the element to be inserted:");
				scanf("%d",&e);
				i=e%max;
				insert(e,i);
				break;
			}
			case 2:{
				int i,e;
				printf("enter the element to be deleted:");
				scanf("%d",&e);
				i=e%max;
				delete(e,i);
				break;
			}
			case 3:{
				for(i=0;i<max;i++)
				display(i);
				break;
			}
		}
	}while(ch!=-1);
}
