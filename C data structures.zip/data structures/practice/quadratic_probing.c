#include<stdio.h>
#include<conio.h>
#define max 7
void insert(int a[],int val);
void display(int a[]);

void insert(int a[],int val)
{
	int index,i,flag=0,hash;
     hash=val;
    for(i=0;i<max;i++)
    {
     index=(hash+i*i)%max;//val%7+(i*(7-val%7))
     if(a[index]==-1)
     {
    	a[index]=val;
         flag=1;
         break;
     }
    }
    if(flag == 0)
     printf("\nelement cannot be inserted\n");
}
void display(int a[])
{
	int i;
	for(i=0;i<max;i++)
	printf("\n%d\t%d",i,a[i]);
}
void main()
{
	int ch,a[max],i;
	for(i=0;i<max;i++)
		a[i]=-1;
	printf("MENU\n1.INSERT\n2.DISPLAY\n");
	printf("enter choice");
	scanf("%d",&ch);
	do
	{
		
		switch(ch)
	{
		case 1:{
			int num,key,i;
			int n;
		
		
			do{
				
					printf("enter the val to be inserted");
			scanf("%d",&num);
				
			insert(a,num);
			printf("enter 1 to continue:");
			scanf("%d",&n);
			}while(n==1);
		
			
			break;
		}
		case 2:{
			display(a);
			break;
		}
	}
	printf("enter choice");
	scanf("%d",&ch);
	}while(ch!=-1);
}
