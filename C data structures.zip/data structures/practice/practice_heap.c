#include<stdio.h>
int tree[100],n=0;
void delheap()
{
	int item = tree[1];
	int last = tree[n];
	n=n-1;
	int loc=1,left=2,right=3;
	printf("the deleted element is %d",item);
	while(right<=n)
	{
		if(last>=tree[left]&&last>=tree[right])
		{
			tree[loc]=last;
			return;
		}
		if(tree[right]<=tree[left])
		{
			tree[loc]=tree[left];
			loc=left;
		}
		else
		{
			tree[loc]=tree[right];
			loc=right;
		}
		left=2*loc;right=2*loc+1;
	}
	if(left==n&&last<tree[left])
	{
		tree[loc]=tree[left];
		loc=left;
	}
	tree[loc]=last;
}
void insheap(int item)
{
	n=n+1;
	int loc=n;//free space
	while(loc>1)
	{
		int par = loc/2;//parent
		if(item<=tree[par])
		{
			tree[loc]=item;
			return;
		}
		tree[loc]=tree[par];//free space will go to parent
		loc=par;
	}
	tree[1]=item;
	return;
}
void main()
{
	int item;
	int ch;
	printf("Menu\n1.insertion\n2.deletion\n3.display\n");
	do
	{
		printf("\nenter the chioce");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:{
				printf("enter the item to be inserted:");
				scanf("%d",&item);
				insheap(item);
				break;
			}
			case 2:{
				delheap();
				break;
			}
			case 3:{
				int i;
				if(n==0)
				{
					printf("no elements in the heap");
				}
				for(i=1;i<=n;i++)
				printf("%d->",tree[i]);
				break;
			}	
		}
	}while(ch!=-1);
}
