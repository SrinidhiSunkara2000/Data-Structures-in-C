#include<stdio.h>
#define size 10
#define max 10
//using namespace std;
int a[size][size],i,j,k;
int front,rear;
int n;
int b[size],q[size],indegree[size];
int create()
{
	front=rear=-1;
	for(i=0;i<max;i++)
	{
		for(j=0;j<max;j++)
		{
			a[i][j]=0;
		}
	}
	for(i=0;i<max;i++)
	indegree[i]=0;
	n=5;
	a[0][2]=1;
	a[0][3]=1;
	a[1][0]=1;
	a[1][3]=1;
	a[2][4]=1;
	a[3][2]=1;
	a[3][4]=1;
/*
	printf("enter the number of vertices:");
	scanf("%d",&n);
	printf("enter the adjacency matrix:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}*/
	return n;
}
void display(int n)
{
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
}
void insert_q(int vertex,int n)
{
	if(rear==n)
	printf("queue overflow");
	else
	{
		if(front==-1)
		front=0;
		rear=rear+1;
		q[rear]=vertex;
	}
}
int delete_q()
{
	int item;
	if(front==-1||front>rear)
	{
		printf("queue underflow\n");
		return -1;
	}
	else
	{
		item=q[front];
		front=front+1;
		return item;
	}
}
int compute_indeg(int node,int n)
{
	int indeg_count=0;
	for(i=0;i<n;i++)
	{
		if(a[i][node]==1)//checking for the incoming edges
		indeg_count++;
	}
	return indeg_count;
}
void topo_ordering(int n)
{
	j=0;
	for(i=0;i<n;i++)
	{
		indegree[i]=compute_indeg(i,n);
		if(indegree[i]==0)
		insert_q(i,n);
	}
	
	while(front<=rear&&j<n)
	{
		k=delete_q();
		b[j++]=k;
		for(i=0;i<n;i++)
		{
			if(a[k][i]==1)
			{
				a[k][i]=0;
				indegree[i]=indegree[i]-1;
				if(indegree[i]==0)
				insert_q(i,n);
			}
		}
	}
	printf("the result after topological sorting is:\n");
	for(i=0;i<n;i++)
		printf(" %d",b[i]);
	printf("\n");
}
void main()
{
	n=create();
	printf("the entered adjacency matrix is:\n");
	display(n);
	topo_ordering(n);
	
}

