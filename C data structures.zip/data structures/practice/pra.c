#include<stdio.h>
int n,i,j,a[20][20],q[20],visited[20],f=0,r=-1,reach[20];
void bfs(int v)
{
	for(i=1;i<=n;i++)
	{
		if(a[v][i]&&!visited[i])
		{
			q[++r]=i;
		}
	}
	if(f<=r)
	{
		visited[q[f]]=1;
	//	printf("%d->",q[f]);
		bfs(q[f++]);
	}
}
void dfs(int v)
{
	reach[v]=1;
	for(i=1;i<=n;i++)
	{
		if(a[v][i]&&!reach[i])
		{
			printf("\n%d->%d",v,i);
			dfs(i);
		}
	}
}
void main()
{
	int v;
	printf("enter the no of vertices");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		q[i]=0;visited[i]=0;reach[i]=0;
	}
	printf("enter the adjacency matrix:");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	/*printf("enter the vertex:");
	scanf("%d",&v);
	bfs(v);*/
	dfs(1);
	for(i=1;i<=n;i++)
	if(reach[i])
	printf("\n%d\t",i);	
	
}
