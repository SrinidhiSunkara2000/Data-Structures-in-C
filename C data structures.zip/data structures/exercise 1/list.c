#include<stdio.h>
#include"test.h"
int a[n],i;
void print(){
	printf("the entered elements are");
	for(i=0;i<n;i++){
		printf("%d\t",a[i]);
	}
}
