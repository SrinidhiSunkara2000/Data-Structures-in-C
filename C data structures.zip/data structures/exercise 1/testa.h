#define no 4
void isempty();
void isfull();
void create();
void insert();
void del();
void search();
void display();
void kpos();
