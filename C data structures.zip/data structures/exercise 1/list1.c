#include"test1.h"
#include<stdio.h>
int i=0,head,ndata,temp,flag=0;
struct{
	int data;
	int next;
	}a[no];

int create(){
	printf("enter the index of the first node");
	scanf("%d",&i);
	head=i;
	while(i!=-1){
		printf("enter the first node and the postion:");
		scanf("%d%d",&a[i].data,&a[i].next);
		i=a[i].next;
	}
	return head;
}
void display(int i){
	while(i!=-1){
		if(a[i].data==-1){
			printf(" ");
		}
		else{
			printf("%d",a[i].data);
		}
		i=a[i].next;
	}
	printf("NULL");
}
void insert(){
	printf("enter the element data to be placed:");
	scanf("%d",&ndata);
	printf("enter the data after which the new data to be placed:");
	scanf("%d",&temp);
	for(i=0;i<no;i++){
		if(a[i].data==temp){
			break;
		}
		
	}
	if(a[i+1].data==-1){
		a[i+1].next=a[i].next;
		a[i].next=i+1;
		a[i+1].data=ndata;
	}
	
}
void search(){
	printf("Enter the node to be deleted: ");
	scanf("%d",&temp);
	for(i=0;i<no;i++){
		if(a[i].data==temp){
			flag=1;
			break;
		}
	}
	if(flag==0)
	printf("not found");
	else
	printf("found");
}
void delete(){
	
}
