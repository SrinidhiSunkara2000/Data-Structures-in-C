#include<stdio.h>
#include"list.c"
void main(){
printf("enter the elements:");
for(i=0;i<n;i++){
	scanf("%d",&a[i]);
}
print();
}
