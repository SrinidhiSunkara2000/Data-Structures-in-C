#include<stdio.h>
#include"testa.h"
#include"lista.c"

void main(){
    int choice;
    do{
        printf("Menu\n1.create\n2.display\n3.insert\n4.delete\n5.search\n6.isempty\n7.isfull\n8.kpos\n9.exit\nenter ur choice: ");
        scanf("%d",&choice);
        switch(choice){
            case 1:{
                create();
                break;
                }
            case 2:{
                display();
                break;
            }    
            case 3:{
                insert();
                break;
            }
            case 4:{
                delete();
                break;
            }
            case 5:{
                search();
                break;
            }
            case 6:{
                isempty();
                break;
            }
                        case 7:{ 
                               isfull();
                               break;
                        }
                        case 8:{ 
                               kpos();
                               break;
                        }
        
        
        }
    }while(choice!=9);

}

     
