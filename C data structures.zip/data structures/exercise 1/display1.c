#include<stdio.h>
#include"test1.h"
#include"list1.c"

void main(){
	int choice;
	do{
		printf("Menu\n1.create\n2.display\n3.insert\n4.delete\n5.search\n6.exit\nenter ur choice: ");
		scanf("%d",&choice);
		switch(choice){
			case 1:{
				for(i=0;i<no;i++){
					a[i].data=-1;
				}
				head=create();
				break;
				}
			case 2:{
				display(head);
				break;
			}	
			case 3:{
				insert();
				break;
			}
			case 5:{
				search();
				break;
			}
		
		}
	}while(choice!=6);
}
	
