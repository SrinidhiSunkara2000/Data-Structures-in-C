#include"testa.h"
#include<stdio.h>
int i=0,head,ndata,temp,flag=0,n,pos;
int a[no];

void isempty(){
    if(n==0){
        printf("is empty");
    }
    else
    printf("the array is not empty");
}
void isfull(){
        if(n==no)
        printf("array is full");
        else
        printf("array is not full");
}
void create(){
    printf("enter the no of elements in the array:");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    
}
void display(){
    for(i=0;i<n;i++){
        
        printf("%d",a[i]);
    }
}
void insert(){
	int x;
	if(n==no){
		printf("cannot insert element");
	}
	else{
		printf("\n1.insert at begining\n2.insertion at end\n3.insert at a particular position\n4.enter the choice:");
		scanf("%d",&x);
		switch(x){
			case 3:{
				 printf("enter the postion of element:");
    scanf("%d",&pos);
    printf("enter the data:");
    scanf("%d",&ndata);
        
    for(i=n-1;i>=pos;i--){
        a[i+1]=a[i];
    }
   
    a[pos]=ndata;
    n=n+1;
				break;
			}
    case 1:{
    	printf("enter the data:");
    	scanf("%d",&ndata);
    	 for(i=n-1;i>=0;i--){
        a[i+1]=a[i];
    }
   
    a[0]=ndata;
    n=n+1;
    	
		break;
	}
	case 2:{
		printf("enter the data:");
		scanf("%d",&ndata);
		a[n]=ndata;
		n=n+1;
		break;
	}
}
}}
void search(){
    printf("Enter the no to be searched: ");
    scanf("%d",&temp);
    for(i=0;i<n;i++){
        if(a[i]==temp){
            flag=1;
            break;
        }
    }
    if(flag==0)
    printf("not found");
    else
    printf("found");
}
void delete(){
    printf("enter the position to be deleted:");
    scanf("%d",&pos);
    for(i=pos;i<n;i++){
        a[i]=a[i+1];
    }
    n=n-1;
}
void kpos(){
       printf("enter the postion:");
       scanf("%d",&pos);
       if(pos<=n)
       printf("element in %d is %d",pos,a[pos]);
}
