#define no 10

int create();
void insert();
void del();
void search();
void display();

