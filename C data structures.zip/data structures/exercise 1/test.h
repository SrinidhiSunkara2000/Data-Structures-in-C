# define n 3
void print();
