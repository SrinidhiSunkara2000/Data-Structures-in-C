#include<stdio.h>
struct student
{
	char name[100];
	int roll_no;
	int marks;
};
void main()
{
	int num,i,j,k;
	
	printf("enter the number of students:");
	scanf("%d",&num);
		struct student s[num],temp;

	for(i=0;i<num;i++)
	{
		printf("enter the name of the student:");
		scanf("%s",s[i].name);
		printf("enter the roll_no of student");
		scanf("%d",&s[i].roll_no);
		printf("enter the marks of the student:");
		scanf("%d",&s[i].marks);
	}
	printf("\nsorting according to the roll_no\n");
	printf("\t\troll_no   name\t marks\n");
	for(i=0;i<num;i++)
	{
		
		for(j=0;j<num-i-1;j++)
		{
		     	if(s[j].roll_no>s[j+1].roll_no)
		     	{
		     		temp = s[j];
		     		s[j] = s[j+1];
		     		s[j+1] = temp;
				 }
			
		}
		printf("iteration %d:",i+1);
			 for(k=0;k<num;k++)
		{
				printf("\n\t\t %d \t %s \t %d\n ",s[k].roll_no,s[k].name,s[k].marks);
		}
		
	}
	printf("\nAfter sorting");
    /*	for(i=0;i<num;i++)
	{
		printf("\nStudent : %d",i+1);
		printf("\nname:%s",s[i].name);
		printf("\nroll_no:%d",s[i].roll_no);
		printf("\nmarks:%d",s[i].marks);
	}*/
		 for(k=0;k<num;k++)
		{
				printf("\n\t\t %d \t %s \t %d\n ",s[k].roll_no,s[k].name,s[k].marks);
		}
	
}
