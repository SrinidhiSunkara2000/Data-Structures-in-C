#include<stdio.h>
struct string
{
	char arr[100];
};
void main()
{
	int num,i,j,small,k;
	printf("enter the number of strings:");
	scanf("%d",&num);
	struct string s[num],temp;
	for(i=0;i<num;i++)
	{
		printf("\nenter string %d:",i+1);
		scanf("%s",s[i].arr);
	}
	for(i=0;i<num;i++)
	{
		small = i;
		for(j=i;j<num;j++)
		{
			if(strcmp(s[j].arr,s[small].arr)<0)
			{
				small = j;
			}
			
		}
		temp = s[small];
		s[small]=s[i];
		s[i]=temp;
		printf("iteration %d:",i+1);
			 for(k=0;k<num;k++)
		{
				printf("\n\t\t%s\n ",s[k].arr);
		}
	}
	printf("after sorting");
	for(i=0;i<num;i++)
	{
		printf("\n String:%d",i+1);
		printf("\t%s\n",s[i].arr);
		
	}
}
