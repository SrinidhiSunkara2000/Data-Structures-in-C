#include<stdio.h>
 
// Function to find largest element
/*int largest(int a[], int n)
{
    int large = a[0], i;
    for(i = 1; i < n; i++)
    {
        if(large < a[i])
            large = a[i];
    }
    return large;
}
 
// Function to perform sorting
void RadixSort(int a[], int n)
{
    int bucket[10][10], bucket_count[10];
    int i, j, k, remainder, NOP=0, divisor=1, large, pass;
 
    large = largest(a, n);
    printf("The large element %d\n",large);
    while(large > 0)
    {
        NOP++;
        large/=10;
    }
 
    for(pass = 0; pass < NOP; pass++)
    {
        for(i = 0; i < 10; i++)
        {
            bucket_count[i] = 0;
        }
        for(i = 0; i < n; i++)
        {
            remainder = (a[i] / divisor) % 10;
            bucket[remainder][bucket_count[remainder]] = a[i];
            bucket_count[remainder] += 1;
        }
 
        i = 0;
        for(k = 0; k < 10; k++)
        {
            for(j = 0; j < bucket_count[k]; j++)
            {
                a[i] = bucket[k][j];
                i++;
            }
        }
        divisor *= 10;
 
        for(i = 0; i < n; i++)
            printf("%d  ",a[i]);
        printf("\n");
    }
}
 */
int max_d(int a[],int n)
{
	int max,i;
	max=a[0];
	for(i=0;i<n;i++)
{
	if(a[i]>max)
	max=a[i];
}
return max;
}
void rs(int a[],int n)
{
	int b[10][10],bc[10],large,divisor=1,remainder=0;
	int pass,nop=0,i,j,k;
	large=max_d(a,n);
	while(large>0)
	{
		nop++;
		large=large/10;
	}
	for(pass=0;pass<nop;pass++)
	{
		for(i=0;i<10;i++)
		bc[i]=0;
		for(j=0;j<n;j++)
		{
			remainder = (a[j]/divisor)%10;
			b[remainder][bc[remainder]]=a[j];
			bc[remainder]+=1;
		}
		i=0;
		for(k=0;k<10;k++)
		{
			for(j=0;j<bc[k];j++)
			{
				a[i]=b[k][j];
				i++;
			}
		}
		divisor*=10;
		printf("\npass%d:\t",pass+1);
	for(i = 0; i < n; i++)
        printf("%d\t",a[i]);

	}
	
}
int main()
{
    int i, n, a[10];
    printf("Enter the number of elements :: ");
    scanf("%d",&n);
    printf("Enter the elements :: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d",&a[i]);
    }
    rs(a,n);
    printf("\nThe sorted elements are :: \n");
    for(i = 0; i < n; i++)
        printf("%d\t",a[i]);
    printf("\n");
    return 0;
}
