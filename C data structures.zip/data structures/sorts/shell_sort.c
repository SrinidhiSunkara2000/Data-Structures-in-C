#include<stdio.h>
 
/*void sort(int a[],int n)
{
    int gap,i,j,temp;
    for(gap=n/2;gap>0;gap/=2)
    {
        for(i=gap;i<n;i+=1)
        {
            temp=a[i];
            
            for(j=i;j>=gap&&a[j-gap]>temp;j-=gap)
                a[j]=a[j-gap];
            
            a[j]=temp;
        }
    }
}*/
void sort(int a[] ,int max)
{
	int m,i,j,temp;
	m=max/2;
	while(m>0)
	{
		for(j=m;j<max;j++)
		{
			for(i=j-m;i>=0;i=i-m)
			{
				if(a[i]>a[i+m])
				{
					temp = a[i];
					a[i]=a[i+m];
					a[i+m]=temp;
				}
				else
				break;
			}
		}
			printf("\ngap%d:\t",m);
	for(i = 0; i < max; i++)
        printf("%d\t",a[i]);
		m=m/2;

	}

	
	
	}

int main()
{
    int a[20],i,n;
    
    printf("Enter number of elements:");
    scanf("%d",&n);
        
    printf("Enter array elements:\n");
    for(i=0;i<n;++i)
        scanf("%d",&a[i]);
 
    sort(a,n);
 
    printf("\nArray after shell sort:\n");
    for(i=0;i<n;++i)
        printf("%d ",a[i]);
 
    return 0;
}
