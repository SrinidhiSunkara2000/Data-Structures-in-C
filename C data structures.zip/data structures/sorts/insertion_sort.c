#include<stdio.h>
#include<string.h>
struct employee
{
	char name[100];
	int salary,no;
};
void main()
{
	int num,i,j,k;
	printf("enter the number of employees:");
	scanf("%d",&num);
	struct employee emp[num],temp;
	for(i=0;i<num;i++)
	{
		printf("enter the name of employee :");
		scanf("%s",emp[i].name);
		printf("enter the employee no:");
		scanf("%d",&emp[i].no);
		printf("enter the salary of the employee");
		scanf("%d",&emp[i].salary);
	}
	printf("sorting according to the names\n");
	printf("\t\tname\tsalary\t number\n");
	for(i=1;i<num;i++)
	{
		printf("\niteration:%d",i);	
		
		j = i;
		while(j>0&&(strcmp(emp[j-1].name,emp[j].name)>0))
		{
			//printf("\niteration:%d",i-1);
			temp = emp[j-1];
		    emp[j-1]=emp[j];
				emp[j]=temp;
			
		j--;
		}
		
	
		for(k=0;k<num;k++)
		{
			
			printf("\n\t\t %s \t%d\t%d\n ",emp[k].name,emp[k].salary,emp[k].no);
		}
	
	}
	printf("\nafter the sorting");
	for(k=0;k<num;k++)
		{
			
			printf("\n\t\t %s \t%d\t%d\n ",emp[k].name,emp[k].salary,emp[k].no);
		}
	
}
