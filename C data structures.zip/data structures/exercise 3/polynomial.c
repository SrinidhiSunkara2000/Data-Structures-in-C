#include<stdio.h>
#include<conio.h>
#include<malloc.h>

struct node{
	int exp;
	int coeff;
	struct node *next;
};

struct node *start=NULL,*p1=NULL,*p2=NULL;

struct node *create_poly(struct node *);
struct node *display_poly(struct node *);
struct node *poly_add(struct node **,struct node **);
struct node *create_poly(struct node *start){
	struct node *new_node,*ptr;
    int n,c;
	printf("enter -1 to stop creating");
		printf("enter the power:");
	scanf("%d",&n);
	printf("enter the coeffiient:");
	scanf("%d",&c);

	     do{
	     	
				new_node=malloc(sizeof(struct node));
				new_node->coeff=c;
				new_node->exp=n;
			if(start==NULL){
				new_node->next=NULL;
				start=new_node;
			}
			else{
				ptr=start;
				while(ptr->next!=NULL){
					ptr=ptr->next;
				}
				ptr->next=new_node;
				new_node->next=NULL;
			}
      	printf("enter the power:");
	scanf("%d",&n);
	printf("enter the coeffiient:");
	scanf("%d",&c);
	}	while(n!=-1);
	return start;
}
struct node *display_poly(struct node *start){
	struct node *ptr;
	ptr=start;
	while(ptr!=NULL){
		printf("(%dx^%d)+",ptr->coeff,ptr->exp);
		ptr=ptr->next;
	}
	return start;
}
struct node *poly_add(struct node **p1,struct node **p2)
{
	 struct node *ptr1,*ptr2,*ptr,*new_node,*ptrr;
	 ptr1=*p1;
	 ptr2=*p2;
	 new_node=malloc(sizeof(struct node));
     
	 ptr=new_node;
	 while(ptr1->next && ptr2->next){
	 	if(ptr1->exp>ptr2->exp){
	 		ptr->coeff=ptr1->coeff;
	 		ptr->exp=ptr1->exp;
	 		ptr1=ptr1->next;
		 }
		 else if(ptr1->exp<ptr2->exp){
		 	ptr->coeff=ptr1->coeff;
		 	ptr->exp=ptr2->exp;
		 	ptr2=ptr2->next;
		 }
		 else if(ptr1->exp==ptr2->exp){
		 	ptr->coeff=ptr1->coeff+ptr2->coeff;
		 	ptr->exp=ptr1->exp;
		 	ptr1=ptr1->next;
		 	ptr2=ptr2->next;
		 	
		 }
		 new_node=malloc(sizeof(struct node));
	 
	 ptr->next=new_node;
	 ptr=ptr->next;}
	 if(ptr1->next) ptrr=ptr1;
	 if(ptr2->next) ptrr=ptr2;
	 while(ptrr->next)
	 {
	 	ptr->coeff=ptrr->coeff;
	 	ptr->exp=ptrr->exp;
	 	new_node=malloc(sizeof(struct node));
	 
	    ptr->next=new_node;
	    ptr=ptr->next;
	    ptrr=ptrr->next;
	 }
	ptr->next=NULL;
	return ptr;	 
}
void main(){
	int ch=0;
	printf("\n1.create p1\n2.create p2\n3.add\n4.display\nenter -1 to exit");
	do{
		printf("enter choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:{
				p1=create_poly(p1);
				break;
			}
			case 2:{
				p2=create_poly(p2);
				break;
			}
			case 3:{
				start=poly_add(&p1,&p2);
				break;
			}
			case 4:{
				start=display_poly(start);
				break;
			}
		}
	}while(ch!=-1);
}

