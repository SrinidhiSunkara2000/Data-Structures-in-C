struct poly* Add(struct poly**, struct poly**);
struct poly* Create();
struct poly* Multiply(struct poly**, struct poly**);
struct poly* recheck(struct poly**);
void print(struct poly**);
