#include<stdio.h>
#include<conio.h>
#include<malloc.h>

struct node{
	int data;
	int pow;
	struct node *next;
};
struct node *start=NULL,*head,*head1;

struct node *create_ll();
void display_ll(struct node *);
struct node* add(struct node **p1,struct node **p2);
struct node *create_ll(){
	start=NULL;
	struct node *ptr,*new_node;
	int num,exp;
	printf("enter -1 for data and -1 for exponent to stop");
	printf("enter the data:");
	scanf("%d",&num);
	printf("enter the pow:");
	scanf("%d",&exp);
	while((num!=-1)&&(exp!=-1)){
		new_node=malloc(sizeof(struct node));
	new_node->data=num;
	new_node->pow=exp;
	new_node->next=NULL;
	if(start==NULL){
	
		start=new_node;
	}
	else{
		ptr=start;
		while(ptr->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=new_node;
		
	}
		printf("enter the data:");
	scanf("%d",&num);
	printf("enter the pow:");
	scanf("%d",&exp);
   }
   return start;
}

void display_ll(struct node *start){
	struct node *ptr;
	ptr=malloc(sizeof(struct node));
	ptr=start;
	if(ptr==NULL){
		printf("the polynomial is empty");
	}
	while(ptr->next!=NULL){
		printf("%dx^%d+",ptr->data,ptr->pow);
		ptr=ptr->next;
	
	}
	printf("%dx^%d",ptr->data,ptr->pow);
	
}
struct node* add(struct node **p1,struct node **p2){
	struct node *p3;
	struct node *ptr1,*ptr2;
	p3=malloc(sizeof(struct node));
	head = *p1;head1 = *p2;
	ptr1=head;ptr2=head1;
	while((ptr1->next!=NULL)&& (ptr2->next!=NULL)){
		if(ptr1->pow==ptr2->pow){
			p3->pow = ptr1->pow;
            p3->data = ptr1->data+ptr2->data;
            ptr1 = ptr1->next;
            ptr2 = ptr2->next;
		}
		else if(ptr1->pow>ptr2->pow){
			p3->pow=ptr1->pow;
			p3->data=ptr1->data;
			ptr1=ptr1->next;
		}
		else if(ptr1->pow<ptr2->pow){
			p3->pow=ptr2->pow;
			p3->data=ptr2->data;
			ptr2=ptr2->next;
		}
	
		p3=p3->next;
		p3->next=NULL;
	}

	return p3;
}
void main(){
	int ch;
	struct node *p1,*p2,*p3;
    
	printf("enter the first polynomial");
	p1=create_ll();   
	printf("the first polynomial is:");
	display_ll(p1);	
		printf("enter the second polynomial");
	p2=create_ll();   
	printf("the second polynomial is:");
	display_ll(p2);
		printf("\nafter addition");
	p3=add(&p1,&p2);

	display_ll(p3);	
}
