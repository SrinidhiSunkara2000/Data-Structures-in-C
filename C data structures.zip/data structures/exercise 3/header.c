#include<stdio.h>
#include<stdlib.h>
#include "header.h"
struct poly{
int coef;
int exp;
struct poly *next;
}*curr,*newnode,*head,*head1,*sum,*curr1,*curr2,*pro,*r;
int n,i,j,tempcoef,tempexp;
struct poly* Create()
{
printf("\nenter the number of terms");
scanf("%d",&n);
for(i=0;i<n;i++)
{
 newnode=malloc(sizeof(struct poly));
 printf("\nenter coeff");
 scanf("%d",&newnode->coef);
 printf("\nenter the exponent of x");
 scanf("%d",&newnode->exp);
 newnode->next=NULL;
if(i==0)
head=newnode;
else 
{
 curr=head;
 while(curr->next!=NULL)
  curr=curr->next;
 curr->next=newnode;
    }
}
return head;
}
void print(struct poly **p)
{
head=*p;
curr=head;
while(curr!=NULL)
{
printf("%d x^%d +",curr->coef,curr->exp);
curr=curr->next;
}
printf("0");
}

struct poly* Add(struct poly **p,struct poly **q)
{
head=*p;
head1=*q;
curr=head;
curr1=head1;
while((curr1!=NULL)&&(curr!=NULL))
{
if(curr->exp>curr1->exp)
{
    tempcoef=curr->coef;
    tempexp=curr->exp;
    curr=curr->next;
}
else if(curr->exp<curr1->exp)
{
 tempcoef=curr1->coef;
 tempexp=curr1->exp;
 curr1=curr1->next;
}
else if(curr->exp==curr1->exp)
{
 tempcoef=curr->coef+curr1->coef;
 tempexp=curr->exp;
 curr=curr->next;
 curr1=curr1->next;
}   
newnode=malloc(sizeof(struct poly));
newnode->coef=tempcoef;
newnode->exp=tempexp;
newnode->next=NULL;

if(sum==NULL)
sum=newnode;
else
{
curr2=sum;
while(curr2->next!=NULL)
{
 curr2=curr2->next;}
 curr2->next=newnode;
} 
}//end of while loop
if(sum->next==NULL)//when nothing is added
curr2=sum;
else
curr2=curr2->next;
 if((curr==NULL)&&(curr1!=NULL))
  curr2->next=curr1;
 else if((curr1==NULL)&&(curr!=NULL))
   curr2->next=curr;
return sum;
}
struct poly* Multiply(struct poly **p,struct poly**q)
{
int count1=0,count2=0;
head=*p;
head1= *q;
curr=head;
while(curr!=NULL)
{
 count1++;
 curr=curr->next;
}
 curr1=head1;
while(curr1!=NULL)
{
 count2++;
 curr1=curr1->next;
}
 curr=head;curr1=head1;
for(i=0;i<count1;i++)
{
 curr1=head1;
 for(j=0;j<count2;j++)
 {
  newnode=malloc(sizeof(struct poly));
 newnode->coef=curr->coef*curr1->coef;
  newnode->exp=curr->exp+curr1->exp;
  newnode->next=NULL;
   if((i==0)&&(j==0))
   pro=newnode; 
   else
  {
  curr2=pro;
while(curr2->next!=NULL)
{curr2=curr2->next;}
curr2->next=newnode;
}
curr1=curr1->next;
}
curr=curr->next;
}
 pro=recheck(&pro);
return pro;
}

struct poly* recheck(struct poly **p)
{

head=*p;

tempcoef=0;tempexp=0;
curr=head;
int count=0;
while(curr!=NULL)
{
count++;
curr=curr->next;
}

curr=head;

while(curr!=NULL)
{
 curr1=curr->next;

 tempcoef=curr->coef;
 tempexp=curr->exp;
 while(curr1!=NULL)
 {
  if(curr->exp==curr1->exp)
 {
  tempcoef+=curr1->coef;
  curr1->exp=-1;
 }  
 curr1=curr1->next;
}
            
if(curr->exp!=-1){
        newnode=malloc(sizeof(struct poly));
newnode->coef=tempcoef;
newnode->exp=tempexp;
newnode->next=NULL;
if(r==NULL)
r=newnode;
else
{
curr2=r;
while(curr2->next!=NULL)
{curr2=curr2->next;}
curr2->next=newnode;
}
}
curr=curr->next;
}
return r;
}
