#include<stdio.h>


#include"list.c"
int main(){
	int ch;
	struct node *p1,*p2,*p3;

	    do{
		printf("\nMENU\n1.create\n2.display\n3.inser_beg\n4.insert_end\n5.insert_after\n6.delete_beg\n7.delete_end\n8.delete_node\n9.getlength\n10.make_empty\n11.find\n12.findk\nenter -1 to exit\n enter choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:{
				p1=create_ll();
				break;
	        }
	        case 2:{
	        	p2=create_ll();
				break;
			}
	        case 3:{
	        	start=display_ll(start);
				break;
			}
        }	
		}while(ch!=-1);
		return 0;
}
