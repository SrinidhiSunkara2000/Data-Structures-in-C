#include<stdio.h>
#include "header.c"
void main()
{
struct poly *p1,*p2,*p3,*p4;
printf("polynomial 1\n");
p1=Create();
printf("\npolynomial 2\n");
p2=Create();
printf("\nThe first polynomial is:\n");
print(&p1);
printf("\nThe second polynomial is:\n");
print(&p2);
    p3=Add(&p1,&p2);
printf("\nthe sum of the polynomials is\n");
print(&p3);
p4=Multiply(&p1,&p2);
printf("\nthe product of the polynomials is\n");
print(&p4);
}
