#include<stdio.h>

struct employee
{
	char name[100];
	int no,salary;
};
/*bs(struct employee emp[],int first,int last,int key)
{
	if(first>last)
	{
		return -1;
	}
	int mid = (first+last)/2;
	if(emp[mid].no==key)
	{
		return mid;
	}
	if(emp[mid].no>key)
	{
		return bs(emp,first,mid-1,key);
	}
	else if(emp[mid].no<key)
	{
		return bs(emp,mid+1,last,key);
	}
}*/
void main()
{
	int num,ch,i,mid,found=0,first,last,temp,count=0;
	printf("enter the number of employees:");
	scanf("%d",&num);
	struct employee emp[num];
	for(i=0;i<num;i++)
	{
		printf("enter details of employee %d :",i+1);
		printf("employee name:");
		scanf("%s",emp[i].name);
		printf("employee no:");
		scanf("%d",&emp[i].no);
		printf("employee salary:");
		scanf("%d",&emp[i].salary);
	}

	do{
		count=0;found=0;
			printf("enter the employee no to search");
	scanf("%d",&temp);
	first=0;last=num-1;
	while(first<=last)
	{
		
		count++;
		mid=(first+last)/2;
		if(emp[mid].no==temp)
		{
			found = 1;
			//printf("element found");
			break;		
		}
	    if(emp[mid].no>temp)
		{
			last = mid-1;
		}
		else if(emp[mid].no<temp)
		{
			first = mid+1;
		}
		
		
	}
	//printf("%d",found);
	if(found == 1)
	{
	printf("\nelement found");
	printf("\n no of passes:%d",count);
    }
   else
     {
	printf("\nelement not found"); 
	printf("\n no of passes:%d",count);
    }
    printf("\nenter 1 to continue 0 to exit:");
    scanf("%d",&ch);
}while(ch!=0);
}
