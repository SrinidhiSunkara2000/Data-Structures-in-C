#include<stdio.h>
#include<string.h>
struct string
{
	char arr[100];
};
void main()
{
	int num,i,ch,found=0,count=0;
	printf("enter the no of strings:");
	scanf("%d",&num);
	struct string s[num],temp,ele;
	printf("\n enter the strings:");
	for(i=0;i<num;i++)
	{
		printf("\n enter the string %d:",i+1);
		scanf("%s",s[i].arr);	
			
	}
	do{
	printf("\nenter the string to be found:");
	scanf("%s",ele.arr);
	count=0;
	for(i=0;i<num;i++)
	{
		count++;
		if(strcmp(ele.arr,s[i].arr)==0)
		{
			found=1;
			break;
			
		}
	/*	else{
			count++;
		}*/
		
		
	}
	if(found==0)
	{
		printf("\nstring not found");
		printf("\nno of traversals made:%d",count);
	}
	else
	{
		printf("\nstring found in %d place",i+1);
			printf("\nno of traversals made:%d",count);
		
	}
	printf("\npress 1 to continue else 0:");
	scanf("%d",&ch);
	
  }while(ch!=0);
}
