#include<stdio.h>
#include"list.c"
void main(){
	struct node *ptr,*start1=NULL,*ptr1,*postptr,*ptr3;
	int i,j,count=0;
	start=create_ll(start);
	ptr=start;
	preptr=start;
	postptr=start->next;
	/*while(postptr->next!=NULL){
		if(ptr->data<postptr->data){
			ptr3=postptr->next;
			postptr->next=ptr;
			ptr->next=ptr3;
		}
		ptr=ptr->next;
		postptr=postptr->next;
	}
	while(ptr!=NULL){
		  ptr=ptr->next;
		  count=count+1;
	
	}
	ptr=start;
	for(i=0;i<count;i++){
		for(j=i;j<count;j++){
			if(ptr->data<postptr->data){
					ptr3=ptr->next;
				preptr->next=postptr;
				ptr->next=
			}
		}
	}*/
	while(ptr->next!=NULL){
		  ptr=ptr->next;
		  count=count+1;
	
	}
	ptr=start;
	preptr=start;
	for(i=0;i<count;i++){
			preptr=start;
		for(j=i;j<count;j++){
			if(ptr->data>preptr->data){
				
			}
		}
	}
	
	ptr=start;
	while(ptr!=NULL){
		printf("%d",ptr->data);
		ptr=ptr->next;
	}	
	
	
}
