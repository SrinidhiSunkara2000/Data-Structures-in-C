#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct node{
	int data;
	struct node *next;
};
struct node *start=NULL;
struct node *create_ll(struct node *);
struct node *display_ll(struct node *);
struct node *insert_beg(struct node *);
struct node *insert_end(struct node *);
struct node *insert_after(struct node *);
struct node *delete_beg(struct node *);
struct node *delete_end(struct node *);
struct node *delete_node(struct node *);
struct node *getlength(struct node *);
struct node *make_empty(struct node *);
struct node *find(struct node *);
struct node *findk(struct node *);
struct node *reverse(struct node *);
struct node *create_ll(struct node *start){
	struct node *new_node,*ptr;

	int num;
	printf("enter -1 to stop creating\n");
	num=0;
	printf("enter the data for new element:");
		scanf("%d",&num);
	do{
	    	
	
		new_node=malloc(sizeof(struct node));
		new_node->data=num;
		new_node->next=NULL;
		if(start==NULL)
		{
			new_node->next=NULL;
			start=new_node;
		}
		else{
			ptr=start;
			while(ptr->next!=NULL){
				ptr=ptr->next;
			}
			ptr->next=new_node;
			//new_node->next=NULL;
		}
		printf("enter the data for new element:");
		scanf("%d",&num);		
		
	}while(num!=-1);
	
	return start;
}
struct node *display(struct node *start){
	struct node *ptr;
	ptr=start;
	while(ptr!=NULL){//not ptr->next
		printf("%d\t",ptr->data);
		ptr=ptr->next;
	}
	return start;
}
struct node *insert_beg(struct node *start){
	struct node *new_node;
	int num;
	new_node=malloc(sizeof(struct node));
	printf("enter the data of new element:");
	scanf("%d",&num);
	new_node->data=num;
	new_node->next=start;
	start=new_node;
	return  start;
}
struct node *insert_end(struct node *start){
	struct node *ptr,*new_node;
	int num;
	new_node=malloc(sizeof(struct node));
	printf("enter the data of new element:");
	scanf("%d",&num);
	new_node->data=num;
	ptr=start;
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	ptr->next=new_node;
	new_node->next=NULL;
	return start;
}
struct node *delete_beg(struct node *start){
	struct node *ptr;
	ptr=start;
	start=start->next;
	free(ptr);
	return start;
}
struct node *delete_end(struct node *start){
	struct node *ptr,*preptr;
	ptr=start;
	while(ptr->next!=NULL){
		preptr=ptr;
		ptr=ptr->next;
	}
	preptr->next=NULL;
	free(ptr);
	return start;
}
struct node *delete_node(struct node *start){
	struct node *ptr,*preptr;
	int num;
	printf("enter the value:");
	scanf("%d",&num);
	ptr=start;
	if(ptr->data==num){
		ptr=start;
		start=start->next;
		free(ptr);
		return start;
	}
	else{
		
		while(ptr->data!=num){
			preptr=ptr;
			ptr=ptr->next;
		}
		preptr->next=ptr->next;
		
		return start;
	}
}
struct node *getlength(struct node *start){
	struct node *ptr;
	int num;
	ptr=start;
	while(ptr!=NULL){//not ptr->next!=NULL;
		num=num+1;
		ptr=ptr->next;
	}
	printf("number of elements are %d",num);
	return start;
}
struct node *make_empty(struct node *start){
	struct node *ptr,*preptr;
	ptr=start;
	while(ptr->next!=NULL){
		preptr=ptr;
		ptr=ptr->next;
		free(preptr);	
	}
	free(ptr);
	return start;
}
struct node *find(struct node *start){
	int num,found=0,pos=0;
	struct node *ptr;
	printf("enter the value to search:");
	scanf("%d",&num);
	ptr=start;
	while(ptr!=NULL){
		if(ptr->data==num)
		{
			found=1;
			printf("element found in %d",pos);
		
			break;
		}
			pos=pos+1;
		ptr=ptr->next;
	}
	if(found==0){
	printf("not found");}
	return start;
}
struct node *findk(struct node *start){
	int num,i=0;
	struct node *ptr;
	printf("enter the position to search:");
	scanf("%d",&num);
	ptr=start;
	for(i=0;i<num;i++)
	ptr=ptr->next;
	printf("the data in %d position is %d",num,ptr->data);
	return start;
}
struct node *insert_after(struct node *start){
	struct node *ptr,*preptr,*new_node;
	int num,temp,i;
	new_node=malloc(sizeof(struct node));
	printf("enter the data of node to be inserted:");
	scanf("%d",&num);
	new_node->data=num;
	printf("enter the position of node: ");
	scanf("%d",&temp);
	ptr=start;
	preptr=start;
	if(temp==0){
		new_node->next=start;
		start=new_node;
	}
	else{
		for(i=0;i<temp;i++){
		preptr=ptr;
		ptr=ptr->next;
	}
		preptr->next=new_node;
	new_node->next=ptr;
	}


	return start;
}
struct node* reverse(struct node *start){
	int count=0,i,j;
	struct node *ptr;
	
	ptr=start;
	while(ptr!=NULL){
		count=count+1;
		ptr=ptr->next;
	}
 
	for(i=0;i<count;i++){
		ptr=start;
		for(j=0;j<(count-i-1);j++){
			ptr=ptr->next;		
		}
		printf("%d->",ptr->data);
	}
	return start;
}
