#include<stdio.h>
#include"list.c"
void main(){
	struct node *start1=NULL,*ptr1,*ptr;
	printf("create a linked list1:");
	start=create_ll(start);
	printf("\ncreate linked list 2:\n");
	start1=create_ll(start1);
	ptr=start;
	ptr1=start1;
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	ptr->next=start1;
	printf("display of concatenated list is: ");
    ptr=start;
	while(ptr!=NULL){
		printf("%d\t",ptr->data);
		ptr=ptr->next;
	}
}
