#include<stdio.h>
#include"list.c"
void main(){
	struct node *start1=NULL,*start2=NULL,*ptr1,*ptr2,*ptr;
	int count,i;
	printf("create a linked list:");
	start=create_ll(start);
	ptr=start;
	while(ptr!=NULL){
		ptr=ptr->next;
		count=count+1;
	}
	ptr=start;
	for(i=0;i<count;i++){
		if(i%2==0){
			struct node *new_node;
			new_node=malloc(sizeof(struct node));
			new_node->data=ptr->data;
			if(start1==NULL){
				new_node->next=NULL;
				start1=new_node;
			}
			else{
				ptr1=start1;
				while(ptr1->next!=NULL){
					ptr1=ptr1->next;
				}
				ptr1->next=new_node;
				new_node->next=NULL;
			}
		}
		else{
				struct node *new_node;
			new_node=malloc(sizeof(struct node));
			new_node->data=ptr->data;
			if(start2==NULL){
				new_node->next=NULL;
				start2=new_node;
			}
			else{
				ptr2=start2;
				while(ptr2->next!=NULL){
					ptr2=ptr2->next;
				}
				ptr2->next=new_node;
				new_node->next=NULL;
			}
		}
		ptr=ptr->next;
	}
	printf("printing list 1:\t");
		ptr1=start1;
        while(ptr1!=NULL){
        	printf("%d\t",ptr1->data);
        	ptr1=ptr1->next;
		}
		printf("\nprinting list 2:\t");
		ptr2=start2;
		  while(ptr2!=NULL){
        	printf("%d\t",ptr2->data);
        	ptr2=ptr2->next;
		}
}
