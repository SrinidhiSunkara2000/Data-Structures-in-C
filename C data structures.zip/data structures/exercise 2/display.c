#include<stdio.h>


#include"list.c"
void main(){
	int ch;

	do{
		printf("\nMENU\n1.create\n2.display\n3.inser_beg\n4.insert_end\n5.insert_after\n6.delete_beg\n7.delete_end\n8.delete_node\n9.getlength\n10.make_empty\n11.find\n12.findk\nenter -1 to exit\n enter choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:{
				start=create_ll(start);
				break;
			}
			case 2:{
				start=display(start);
				break;
			}
			case 3:{
				start=insert_beg(start);
				break;
			}
			case 4:{
				start=insert_end(start);
				break;
			}
			case 5:{
				start=insert_after(start);
				break;
			}
			case 6:{
				start=delete_beg(start);
				break;
			}
			case 7:{
				start=delete_end(start);
				break;
			}
			case 8:{
				start=delete_node(start);
				break;
			}
			case 9:{
				start=getlength(start);
				break;
			}
			case 10:{
				start=make_empty(start);
				break;
			}
			case 11:{
				start=find(start);
				break;
			}
			case 12:{
				start=findk(start);
				break;
			}
		}
	}while(ch!=-1);
}
