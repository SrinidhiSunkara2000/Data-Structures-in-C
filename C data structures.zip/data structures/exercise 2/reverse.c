#include<stdio.h>
#include"list.c"
void main(){
	int ch;
	printf("1.create a linked list\n2.print in reverse order\nenter -1 to exit\n");
	do{
		printf("enter choice:");
		scanf("%d",&ch);
	switch(ch){
		case 1:{
			start=create_ll(start);
			break;
		}
		case 2:{
			start=reverse(start);
			break;
		}
	}
	
	}while(ch!=-1);
	


}
