#include"headerl.h"
void main()
{
	char a[200];
	struct stack *start;
	int length=0,i=0;
	printf("enter the expression:");
	scanf("%s",a);
	while(a[i]!='\0'){
		length=length+1;
		i=i+1;
	}
	for(i=0;i<length;i++){
			char ch;
		ch=a[i];
		if(ch=='+'||ch=='-'||ch=='*'||ch=='/'){
			int *a,*b;
		
			start=pop(start);
			a=start;
			start=pop(start);
			b=start;
			switch(ch){
				case '+':{
					push(*a+*b);
					break;
				}
				case '-':{
					push(*a-*b);
					break;
				}
				case '*':{
					push((*a)*(*b));
					break;
				}
				case '/':{
					push((*a)/(*b));
					break;
				}
			}
		}
		else{
			push(start,a[i]);
		}
	}
	start=top(start);
}
