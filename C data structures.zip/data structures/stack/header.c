#include"header.h"

struct stack{
	int a[max];
	int top;
};
struct stack s;

int item,n;
void create(){
	int i;
	printf("maximum size is 5\nenter the no of elements in the stack:");
	scanf("%d",&n);
	if(n<max){
		for(i=0;i<n;i++){
			s.a[i]=0;
		}
	}
	else
	printf("cannot create");
}
void dispose(){
	s.top=-1;
	n=0;
}
int isfull(){
	if(s.top==n-1)
{printf("\nstack is full");	return 1;}
	else
	{printf("\nstack is not full");return 0;}
}
int isempty(){
	if(s.top==-1)
	{
		printf("\nstack is empty");
	return 1;}
	else{
		printf("\nstack is not empty");
	return 0;}
}
void push(){
	if(s.top==n-1){
		printf("\nstack is already full cannot insert elements\n");
		
	}
	else{
		printf("\nenter the element to be inserted:");
		scanf("%d",&item);
		s.top=s.top+1;
		s.a[s.top]=item;
	}
	
	display();
}
void pop(){
	if(isempty()==1){
		printf("\nstack is empty cannot delete elements\n");
		
	}
	else{
		item=s.a[s.top];
		printf("\nthe element deleted is:%d\n",item);
		s.top=s.top-1;
	}
	display();
}
void display(){
	int i;

	for(i=0;i<=s.top;i++){
		item=s.a[i];
		if(i==s.top)
			printf("top-->");
		printf("\t%d\n",item);
	}
}
int top(){
	printf("\nthe top element is %d",s.a[s.top]);
	return s.a[s.top];
}
