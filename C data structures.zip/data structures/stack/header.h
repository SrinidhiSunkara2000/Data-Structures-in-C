#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<malloc.h>
#define max 5

