#include"headerl.h"
struct node{
	char data;
	struct node *next;
};
struct node *top=NULL;
void push(char);
void pop();
void push(char x)
{
	struct node *temp=malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	if(top==NULL)
	top=temp;
	else
	{
		struct node *ptr;
		ptr=top;
		temp->next=ptr;
		top=temp;
	}
}
int isEmpty()
{
	if(top==NULL)
	return 1;
	else
	return 0;
}
char istop()
{
	return top->data;
}
void pop()
{
	struct node *temp;
	
	if(top!=NULL){
		temp=top;
	top=top->next;
	free(temp);}
	else{
		printf("cant delete elements as stack is already empty");
	
	}
}

void display()
{
	if(top==NULL)
	printf("stack is empty");
	else
	{
		struct node *temp;
		temp=top;
		while(temp!=NULL)
		{
			printf("%c",temp->data);
			temp=temp->next;
		}
	}
}
int check_balance(char s[],int len)
{
	int i;
	for(i=0;i<len;i++)
    {
    	if((s[i]=='[')||(s[i]=='{')||(s[i]=='('))
    	{
    		push(s[i]);
		}
		else if((s[i]==']')||(s[i]=='}')||(s[i]==')'))
		{
			if(top==NULL)
			{
				return;
			}
			else if((s[i]==')')&&(top->data=='(')){
				pop();
			}
			else if((s[i]==']')&&(top->data=='[')){
				pop();
			}
			else if((s[i]=='}')&&(top->data=='{')){
				pop();
			}
			
		}
		
	}
	return (top==NULL)?(1):(0);
}
int isOperand(char ch)
{
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}
 
// A utility function to return precedence of a given operator
// Higher returned value means higher precedence
int Prec(char ch)
{
    switch (ch)
    {
    case '+':
    case '-':
        return 1;
 
    case '*':
    case '/':
        return 2;
 
    case '^':
        return 3;
    }
    return -1;
}
 
 
// The main function that converts given infix expression
// to postfix expression. 
int infixToPostfix(char* exp)
{
    int i, k;
    char a[100];
 
    // Create a stack of capacity equal to expression size 
  /*  struct Stack* stack = createStack(strlen(exp));
    if(!stack) // See if stack was created successfully 
        return -1 ;
        */
 
    for (i = 0, k = -1; exp[i]; ++i)
    {
        // If the scanned character is an operand, add it to output.
        if (isOperand(exp[i]))
            a[++k] = exp[i];
         
        // If the scanned character is an �(�, push it to the stack.
        else if (exp[i] == '(')
            push(exp[i]);
         
        // If the scanned character is an �)�, pop and output from the stack 
        // until an �(� is encountered.
        else if (exp[i] == ')')
        {
            while (!isEmpty() && istop() != '(')
                {
				a[++k] = istop();
				pop();
				}
            if (!isEmpty() && istop() != '(')
                return -1; // invalid expression             
            else
                pop();
        }
        else // an operator is encountered
        {
            while (!isEmpty() && Prec(exp[i]) <= Prec(istop()))
                {a[++k] = istop();
                pop();}
            push(exp[i]);
        }
 
    }
 
    // pop all the operators from the stack
    while (!isEmpty())
        {
		a[++k] = istop();
		pop();}
 
    a[++k] = '\0';
    printf( "%s",a);
}
 
// Driver program to test above functions
int evaluatePostfix(char* exp)
{
    // Create a stack of capacity equal to expression size
    //struct Stack* stack = createStack(strlen(exp));
    int i;
 
    // See if stack was created successfully
    //if (!stack) return -1;
 
    // Scan all characters one by one
    for (i = 0; exp[i]; ++i)
    {
        // If the scanned character is an operand (number here),
        // push it to the stack.
        if (isdigit(exp[i]))
            push(exp[i] - '0');
 
        //  If the scanned character is an operator, pop two
        // elements from stack apply the operator
        else
        {
            int val1 = istop();pop();
            int val2 = istop();pop();
            switch (exp[i])
            {
             case '+': {
                 push(val1+val2);
             	
				break;
			 }
             case '-':{
             		if(val2>val1)
             	push(val2 - val1);
             	else
             	push(val1-val2);
				break;
			 } 
             case '*': push(val2 * val1); break;
             case '/': push(val2/val1);   break;
            }
        }
    }
    return istop();
}

   
/*
void main()
{
	char s[100];
	int i,len,ch;
	char exp[100]/* = "a+b*(c^d-e)^(f+g*h)-i"
   ixToPostfix(exp);
	printf("enter the string:");
	scanf("%s",s);
	//printf("%s",s);
	len=strlen(s);
	if(check_balance(s,len))
	{
		printf("paranthesis match");
	}
	else
	printf("not a match");
	printf("Menu\n1.check_balance\n2.infixtopostfix\n3.evaluating a postfix expression\nenter choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:{
			printf("enter the string:");
	scanf("%s",s);
	//printf("%s",s);
	len=strlen(s);
	if(check_balance(s,len))
	{
		printf("paranthesis match");
	}
	else
	printf("not a match");
			
			break;
		}
		case 2:{
			printf("enter an infix expression:");
			scanf("%s",exp);
			infixToPostfix(exp);
			break;
		}
		case 3:{
			 //char exp[] = "231*+9-";
			 printf("enter the postfix expression:");
			 scanf("%s",exp);
           printf ("Value of %s is %d", exp, evaluatePostfix(exp));
			break;
		}
	}
    
	
}*/
