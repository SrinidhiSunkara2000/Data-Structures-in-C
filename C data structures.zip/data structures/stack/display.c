#include"header.c"
void main(){
	int ch=0,x;
	s.top=-1;
	printf("1.isempty\n2.isfull\n3.push\n4.pop\n5.display\n6.create\n7.dispose\n8.top\nenter -1 to exit\n");
	do
	{
		printf("\nenter choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:{
				x=isempty();
				break;
			}
			case 2:{
				x=isfull();
				break;
			}
			case 3:{
				push();
				break;
			}
			case 4:{
				pop();
				break;
			}
			case 5:{
				display();
				break;
			}
			case 6:{
				create();
				break;
			}
			case 7:{
				dispose();
				break;
			}
			case 8:{
				top();
				break;
			}
		}
	}while(ch!=-1);
}
