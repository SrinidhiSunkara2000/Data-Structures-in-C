#include"headerl.c"
void main()
{
	int ch=0,n;
		printf("1.isempty\n2.create\n3.push\n4.pop\n5.display\n6.top\n7.makeempty\nenter -1 to exit\n");
		printf("\nenter the choice:");
	    		scanf("%d",&ch);
	    do{
	    	    
	    		switch(ch){
	    			case 1:{
	    				top=isempty(top);
						break;
					}
	    			case 2:{
	    				top=create(top);
						break;
					}
					case 3:{
						printf("\nenter the element to be pushed:");
						scanf("%d",&n);
						top=push(top,n);
						break;
					}
					case 4:{
						top=pop(top);
						break;
					}
					case 5:{
						top=display(top);
						break;
					}
					case 6:{
						top=istop(top);
						break;
					}
					case 7:{
						top=makeempty(top);
						break;
					}
				}
				printf("\nenter the choice:");
	    		scanf("%d",&ch);
		}while(ch!=-1);
		
}
