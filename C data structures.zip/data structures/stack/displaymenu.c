#include"balancing.c"
void main()
{
	char s[100];
	int i,len,ch;
	char exp[100]/* = "a+b*(c^d-e)^(f+g*h)-i"*/;
   /* infixToPostfix(exp);
	printf("enter the string:");
	scanf("%s",s);
	//printf("%s",s);
	len=strlen(s);
	if(check_balance(s,len))
	{
		printf("paranthesis match");
	}
	else
	printf("not a match");*/
	printf("Menu\n1.check_balance\n2.infixtopostfix\n3.evaluating a postfix expression\nenter -1 to stop\nenter choice:");
	scanf("%d",&ch);
	do{
	switch(ch)
	{
		case 1:{
			printf("enter the string:");
	scanf("%s",s);
	//printf("%s",s);
	len=strlen(s);
	if(check_balance(s,len))
	{
		printf("paranthesis match");
	}
	else
	printf("not a match");
			
			break;
		}
		case 2:{
			printf("enter an infix expression:");
			scanf("%s",exp);
			infixToPostfix(exp);
			break;
		}
		case 3:{
			 //char exp[] = "231*+9-";
			 printf("enter the postfix expression:");
			 scanf("%s",exp);
           printf ("Value of %s is %d", exp, evaluatePostfix(exp));
			break;
		}
	}
		printf("\nMenu\n1.check_balance\n2.infixtopostfix\n3.evaluating a postfix expression\nenter -1 to stop\nenter choice:");
	scanf("%d",&ch);
}while(ch!=-1);
	
}
