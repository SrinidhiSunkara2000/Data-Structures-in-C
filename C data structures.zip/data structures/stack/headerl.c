#include"headerl.h"
struct stack{
	int data;
	struct stack *next;
};
struct stack *top=NULL;
struct stack *ptr,*preptr,*new_node;
struct stack *create(struct stack *);
struct stack *push(struct stack *,int);
struct stack *pop(struct stack *);
struct stack *display(struct stack *);
struct stack *isempty(struct stack *);
struct stack *makeempty(struct stack *);
struct stack *istop(struct stack *);

struct stack *isempty(struct stack *top){
	if(top==NULL){
		printf("stack is empty");
	}
	else{
		printf("stack is not empty");
	}
	return top;
}
struct stack *create(struct stack *top)
{
	int x;
	printf("enter the -1 to stop");
		printf("enter the element");
		scanf("%d",&x);
	do{
	
			new_node=malloc(sizeof(struct stack));
			new_node->data=x;
		
			new_node->next=top;
			top=new_node;
	
		printf("\nenter the element:");
		scanf("%d",&x);
	}while(x!=-1);
	return top;
}
struct stack *push(struct stack *top,int x){
		if(top==NULL)
		{
			top->data=x;
		    top->next=NULL;
		}
		else
		{
			new_node=malloc(sizeof(struct stack));
			new_node->data=x;
			new_node->next=top;
			top=new_node;
		}
		top=display(top);
		return top;
	
}
struct stack *pop(struct stack *top){
	if(top == NULL)
	{
		printf("cannot delete elements as the stack is already empty");
		return;
	}
    else{
	ptr=top;
	printf("\nthe element deleted is:%d",ptr->data);
	top=top->next;
	free(ptr);}
	
	return top;
}
struct stack *display(struct stack *top){
	ptr=top;
	printf("\ttop-->\t");
	while(ptr!=NULL)
	{
		printf("%d\n\t\t",ptr->data);
		ptr=ptr->next;
	}
	return top;
}
struct stack *istop(struct stack *top){
	printf("the top of the element is:%d",top->data);
	return top;
}
struct stack *makeempty(struct stack *top)
{
       
		top=NULL;	
	return top;
}


 
