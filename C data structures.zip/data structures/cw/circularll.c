#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct node{
	int data;
	struct node *next;
};
struct node *head=NULL;
struct node* display(struct node *);
struct node *create(struct node *);
struct node* insert_beg(struct node *);
struct node *insert_end(struct node *);
struct node *insert_after(struct node *);
struct node *delete_beg(struct node *);
struct node *delete_end(struct node *);
struct node *delete(struct node *);
struct node *delete_after(struct node *);
struct node* getnode(int);
struct node* getnode(int x){
	struct node *new_node=malloc(sizeof(struct node));
	new_node->data=x;
	new_node->next=NULL;
	return new_node;
}
struct node *create(struct node *head){
	int x=0;
	struct node *new_node,*ptr;
	printf("enter -1 to exit:");
		printf("enter data:");
		scanf("%d",&x);
	do{	
	new_node=getnode(x);
	if(head==NULL){
		head=new_node;
		new_node->next=head;
	}
	else{
		ptr=head;
		while(ptr->next!=head){
			ptr=ptr->next;
		}
		ptr->next=new_node;
		new_node->next=head;
	}
		printf("enter data:");
		scanf("%d",&x);
	}while(x!=-1);
	return head;
}
struct node* display(struct node *head){
	struct node *ptr;
	ptr=head;
	printf("%d",ptr->data);
	ptr=ptr->next;
	while(ptr!=head){
		printf("%d",ptr->data);
		ptr=ptr->next;
	}
	return head;
}
struct node* insert_beg(struct node *head){
	struct node *new_node,*ptr;
	int x;
	ptr=head;
	printf("enter data:");
	scanf("%d",&x);
	new_node=getnode(x);
	new_node->next=head;

	while(ptr->next!=head){
		ptr=ptr->next;
	}
	ptr->next=new_node;
		head=new_node;
	return head;
}
struct node *insert_end(struct node *head){
	int x;
	struct node *ptr,*new_node;
	printf("enter data:");
	scanf("%d",&x);
	new_node=getnode(x);
	ptr=head;
	while(ptr->next!=head){
		ptr=ptr->next;
	}
	ptr->next=new_node;
	new_node->next=head;
	return head;
}
struct node *insert_after(struct node *head){
	struct node *new_node,*ptr;
	int x,temp;
	ptr=head;
	printf("enter the data:");
	scanf("%d",&x);
	new_node=getnode(x);
	printf("enter the node after which it should be inserted:");
	scanf("%d",&temp);
	do{
		if(ptr->data==temp)
		{
			new_node->next=ptr->next;//else the memory of ptr is lost
			ptr->next=new_node;
			break;
		}
		else
		ptr=ptr->next;
	}while(ptr->next!=head);
	return head;
}
struct node *delete_beg(struct node *head){
	struct node *ptr,*tempptr;
	ptr=head;
	tempptr=head;
	while(ptr->next!=head){
		ptr=ptr->next;
	}
	head=head->next;
	ptr->next=head;
	free(tempptr);
	return head;
}
struct node *delete_end(struct node *head){
	struct node *ptr,*preptr;
	ptr=head;
	while(ptr->next!=head){
		preptr=ptr;
		ptr=ptr->next;
	}
	preptr->next=head;
	free(ptr);
	return head;
}
struct node *delete(struct node *head){
	struct node *ptr,*preptr;
	int data;
	printf("enter the node to be delelted:");
	scanf("%d",&data);
	ptr=head;
	preptr=head;
	if(ptr->data==data)
	head=delete_beg(head);
	else{
	while(ptr->next!=head){
		if(ptr->data==data){
			preptr->next=ptr->next;
			free(ptr);
			break;
		}
		else{
			preptr=ptr;
			ptr=ptr->next;
		}
	}}
	return head;
}
struct node *delete_after(struct node *head){
	int temp;
	struct node *ptr,*postptr;
	ptr=head;
	printf("enter the node after which it should be deleted:");
	scanf("%d",&temp);
	do{
		if(ptr->data==temp){
			break;
		}
		else{
			ptr=ptr->next;
		}
	}while(ptr->next!=head);
	postptr=ptr->next;
	ptr->next=postptr->next;
	free(postptr);
	return head;
}
void main(){
	int ch;
	printf("1.create\n2.display\n3.insert_beg\n4.insert_end\n5.insert_after\n6.delete_beg\n7.delete_end\n8.delete_after\n9.delete\nenter -1 to stop");
	do{
		printf("\nenter choice:");
		scanf("%d",&ch);
		switch(ch){
			case 1:{
				head=create(head);
				break;
			}
			case 2:{
				head=display(head);
				break;
			}
			case 3:{
				head=insert_beg(head);
				break;
			}
			case 4:{
			    head=insert_end(head);
				break;
			}
			case 5:{
				head=insert_after(head);
				break;
			}
			case 6:{
				head=delete_beg(head);
				break;
			}
			case 7:{
				head=delete_end(head);
				break;
			}
			case 8:{
				head=delete_after(head);
				break;
			}
			case 9:{
				head=delete(head);
				break;
			}
		}
		
	}while(ch!=-1);
}
