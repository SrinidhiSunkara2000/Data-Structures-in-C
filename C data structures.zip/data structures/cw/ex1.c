#include<stdio.h>
#include<stdlib.h>

struct link
{
	int data;
	struct link *next;
}*head,*temp,*start=NULL,*head1,*temp1,*start1=NULL,*head2,*temp2,*start2=NULL,*start3=NULL,*head3;

void create(int k)
{
	temp=(struct link *)malloc(sizeof(struct link));
	temp->data=k;
	temp->next=NULL;
	
	if(start==NULL)
	{
		start=temp;
		head=temp;
	}
	else
	{
		head->next=temp;
		head=temp;
	}
}

void create1(int k)
{
	temp=(struct link *)malloc(sizeof(struct link));
	temp->data=k;
	temp->next=NULL;
	
	if(start1==NULL)
	{
		start1=temp;
		head1=temp;
	}
	else
	{
		head1->next=temp;
		head1=temp;
	}
}


void print(struct link *h1)
{
	struct link *temp=h1;
	while(temp!=NULL)
	{
		printf("%d-->",temp->data);
		temp=temp->next;
	}
	printf("X");
}

void merge(struct link *p,struct link **q)
{
	struct link *temp=p,*temp1=*q;
	struct link *t_next,*t1_next;
	
	while(temp!=NULL && temp1!=NULL)
	{
		t_next=temp->next;
		t1_next=temp1->next;
		temp1->next=t_next;
		temp->next=temp1;
		temp=t_next;
		temp1=t1_next;
	}
	*q = temp1;
}

int main()
{
	
	int k,j;
	int n=1,h=1;
	printf("\nElements of 1 list:\n");
	while(n==1)
	{
		printf("\nEnter the value:");
		scanf("%d",&k);
		create(k);
		printf("\nDo u want to continue 1/0:  ");
		scanf("%d",&n);
	}
	printf("\nElements of 2 list:\n");
	while(h==1)
	{
		printf("\nEnter the value:");
		scanf("%d",&k);
		create1(k);
		printf("\nDo u want to continue 1/0:  ");
		scanf("%d",&h);
	}
	printf("\n\nFirst list elements\n\n");
	print(start);
	printf("\n\nSecond list elements\n\n");
	print(start1);
	merge(start,&start1);
	printf("\n\nModified 1 list:\n");
	print(start);
	printf("\n\nModified 2 list:\n");
	print(start1);
}
