#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct node{
	int data;
	struct node *next;
	struct node *prev;
}*ptr;
struct node *get_node(int);
struct node* insert(struct node*);
struct node *insert_beg(struct node *);
struct node *insert_end(struct node*);
struct node *display(struct node *);
struct node *rev_display(struct node*);
struct node *delete_beg(struct node *);
struct node *delete_end(struct node *);
struct node *delete_at(struct node *);
struct node* head=NULL;
struct node* get_node(int x){
	struct node* new_node=malloc(sizeof(struct node));
	new_node->data=x;
	new_node->prev=NULL;
	new_node->next=NULL;
	return new_node;
}
struct node* insert_beg(struct node* head){
	int x;
	struct node *new_node;
	printf("enter the data to be inserted");
	scanf("%d",&x);
	new_node=get_node(x);
	if(head==NULL){
		head=new_node;
	}
	else{
		new_node->next=head;
		head->prev=new_node;
		head=new_node;
	}
 return head;
}
struct node* insert_end(struct node* head){
	int x;
	struct node *new_node;
	printf("enter the data to be inserted");
	scanf("%d",&x);
	new_node=get_node(x);
		if(head==NULL){
		head=new_node;
	}
	else{
		ptr=head;
		while(ptr->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=new_node;
		new_node->prev=ptr;
	}
	return head;
	
}
struct node* insert(struct node* head){
	int data,x,i;
    struct node *new_node;
	printf("enter the data of node after :");
	scanf("%d",&data);
	scanf("%d",&x);
	new_node=get_node(x);
	ptr=head;
	while(ptr->data!=data){
		ptr=ptr->next;
	}
	new_node->prev=(ptr->next);
	new_node->next=(ptr->next)->prev;
	ptr->next=new_node;
	(new_node->next)->prev=new_node;
	return head;
}
struct node* display(struct node* head){
	ptr=head;
	while(ptr!=NULL){
		printf("%d\n",ptr->data);
		ptr=ptr->next;
	}
	return head;
}
struct node* rev_display(struct node *head){
	ptr=head;
	
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	while(ptr!=NULL){
		printf("%d\n",ptr->data);
		ptr=ptr->prev;
	}
	return head;
}
struct node *delete_beg(struct node *head){
	ptr=head;
	head=head->next;
	head->prev=NULL;
	free(ptr);
	return head;
}
struct node *delete_end(struct node *head){
	struct node *store_prev,*store_next;
	ptr=head;
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	store_prev=ptr->prev;
	free(ptr);
	store_prev->next=NULL;
	return head;
}
struct node *delete_at(struct node *head){
	struct node *store_prev,*store_next;
	int pos,i; 
	printf("enter the data:");
	scanf("%d",&pos);
	ptr=head;
	while(ptr->data!=pos){
		ptr=ptr->next;
	}
	store_prev=ptr->prev;
	store_next=ptr->next;
	store_prev->next=store_next;
	store_next->prev=store_prev;
	free(ptr);
	return head;
}
void main(){
      int ch=0;
      printf("1.insert_beg\n2.insert_end\n3.display\n4.rev_display\n5.delete_beg\n6.delete_end\n7.delete\n8.inser\nenter -1 to exit\n");
      do{
      	printf("enter choice:");
      	 scanf("%d",&ch);
      	 switch(ch){
      	 	case 1:{
      	 		head=insert_beg(head);
				break;
			   }
			case 2:{
				head=insert_end(head);
				break;
			}
			case 3:{
				head=display(head);
				break;
			}
			case 4:{
				head=rev_display(head);
				break;
			}
			case 5:{
				head=delete_beg(head);
				break;
			}
			case 6:{
				head=delete_end(head);
				break;
			}
			case 7:{
				head=delete_at(head);
				break;
			}
			case 8:{
				head=insert(head);
				break;
			}
		   }
	  }while(ch!=-1);
      
	 
      
	  }

