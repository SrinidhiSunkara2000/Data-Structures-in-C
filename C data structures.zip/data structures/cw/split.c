#include<stdio.h>
#include<stdlib.h>

struct link
{
	int data;
	struct link *next;
}*head,*temp,*head1,*head2,*start=NULL,*list1=NULL,*list2=NULL,*start1=NULL,*start2=NULL;

void create()
{
	int b=1;
	while(b==1)
	{
		temp=(struct link *)malloc(sizeof(struct link));
		printf("\nEnter the value:");
		scanf("%d",&temp->data);
		temp->next=NULL;
	
		if(start==NULL)
		{
			start=temp;
			head=temp;
		}
		else
		{
			head->next=temp;
			head=temp;
		}
		printf("Continue 1/0  ");
		scanf("%d",&b);
	}
}

void split()
{
	int i=1;
	temp=start;
	
	struct link *ptr,*temp1;
	
	while(temp!=NULL)
	{
		if(i%2==1)
		{
			ptr=(struct link *)malloc(sizeof(struct link));
			ptr->data=temp->data;
			ptr->next=NULL;
	
			if(start1==NULL)
			{
				start1=ptr;
				head1=ptr;
			}
			else
			{
				head1->next=ptr;
				head1=ptr;
			}
		}
		else
		{
			ptr=(struct link *)malloc(sizeof(struct link));
			ptr->data=temp->data;
			ptr->next=NULL;
	
			if(start2==NULL)
			{
				start2=ptr;
				head2=ptr;
			}
			else
			{
				head2->next=ptr;
				head2=ptr;
			}
		}
		temp=temp->next;
		i++;
	}
}


void display(struct link *p)
{
	temp=p;
	while(temp!=NULL)
	{
		printf("%d --> ",temp->data);
		temp=temp->next;
	}
}


int main()
{
	printf("Enter the elements into the list :\n");
	create();
	printf("The elemnts of the list are: ");
	display(start);
	split();
	printf("\nThe elements of 1 list : ");
	display(start1);
	printf("\nThe elements of 2 list : ");
	display(start2);
}
